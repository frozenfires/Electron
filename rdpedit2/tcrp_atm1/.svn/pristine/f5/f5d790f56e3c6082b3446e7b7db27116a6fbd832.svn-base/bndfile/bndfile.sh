#!/bin/sh

##Need Bndfile= libDev3Des_ifx.bnd libUserFunDb30.bnd libtask.bnd   libtcpdb30.bnd libusrbusidb.bnd worklog30_db.bnd

#db2 connect to $BASESERV
db2 connect to $BASESERV user $DBUSER using $DBPASSWD 
db2 bind libUserFunDb30.bnd
#db2 bind libDev3Des_ifx.bnd 
db2 bind libtask.bnd
db2 bind libtcpdb30.bnd
#db2 bind libusrbusidb.bnd
db2 bind worklog30_db.bnd
db2 bind libPCommon.bnd
db2 bind libCoreCommon.bnd
db2 bind libP4020.bnd
db2 bind libP8000.bnd
db2 bind libP8001.bnd
db2 bind libP8605.bnd
db2 bind libP3126.bnd
db2 bind libP3124.bnd
db2 bind libP3134.bnd
db2 bind libP3300.bnd
db2 bind  libTCRCommon.bnd
exit

