-- This CLP file was created using DB2LOOK Version "9.7" 
-- Timestamp: 2014��02��13�� ������ 16ʱ39��43��
-- Database Name: TCRMDB         
-- Database Manager Version: DB2/LINUXX8664 Version 9.7.3  
-- Database Codepage: 1386
-- Database Collating Sequence is: UNIQUE


CONNECT TO TCRMDB USER tcrm;

------------------------------------------------
-- DDL Statements for table "ATMP    "."WSUNIT"
------------------------------------------------
 

CREATE TABLE "ATMP    "."WSUNIT"  (
		  "UNTID" VARCHAR(8) NOT NULL , 
		  "UNTNAME" VARCHAR(40) NOT NULL , 
		  "MDLID" VARCHAR(8) NOT NULL , 
		  "DPTID" VARCHAR(8) NOT NULL , 
		  "VDRNUM" VARCHAR(32) , 
		  "BRANCH" CHAR(16) , 
		  "MERCHANTTYPE" VARCHAR(4) , 
		  "MERCHANT" CHAR(16) , 
		  "TELLERID" CHAR(16) , 
		  "CARDNUM" CHAR(20) , 
		  "NETTYPE" CHAR(1) , 
		  "NETADDR" CHAR(32) , 
		  "SUBADDR1" CHAR(8) , 
		  "SUBADDR2" CHAR(8) , 
		  "TIMEOUT" INTEGER WITH DEFAULT 0 , 
		  "INTERCNT" INTEGER WITH DEFAULT 0 , 
		  "CHANNEL" INTEGER , 
		  "MAXLEN" INTEGER WITH DEFAULT 0 , 
		  "HDRTYPE" CHAR(1) , 
		  "COORDX" INTEGER , 
		  "COORDY" INTEGER , 
		  "REVFLAG" CHAR(1) , 
		  "STASENDFLAG" CHAR(1) , 
		  "WORKKEY" CHAR(16) , 
		  "FITUPDATE" CHAR(1) , 
		  "BALACCFLAG" CHAR(1) , 
		  "TERMINAL" CHAR(16) , 
		  "CHANNEL2" INTEGER , 
		  "WORKKEYFLAG" CHAR(1) , 
		  "RECVTIMEOUT" INTEGER , 
		  "STARTHTM" VARCHAR(70) , 
		  "STOPHTM" VARCHAR(70) , 
		  "WINSIZE" VARCHAR(1) , 
		  "FTPIP" VARCHAR(16) , 
		  "FTPPORT" VARCHAR(8) , 
		  "LOCALPATH" VARCHAR(30) , 
		  "REMOTEPATH" VARCHAR(30) , 
		  "CRPORT" VARCHAR(5) , 
		  "PR2PORT" VARCHAR(5) , 
		  "LPTPORT" VARCHAR(5) , 
		  "PRINTWPORT" VARCHAR(5) , 
		  "PRINTFPORT" VARCHAR(5) , 
		  "ADMINPIN" VARCHAR(10) , 
		  "RESV1" VARCHAR(10) , 
		  "RESV2" VARCHAR(10) , 
		  "ATTR" INTEGER , 
		  "AREAID" VARCHAR(8) , 
		  "MACHNO" INTEGER WITH DEFAULT 0 , 
		  "BATCHNO" INTEGER WITH DEFAULT 0 , 
		  "MAXTFAMT" VARCHAR(12) , 
		  "MAXTRANAMT" VARCHAR(12) , 
		  "MAXTFTIMES" VARCHAR(12) , 
		  "ENABLEDATE" VARCHAR(8) , 
		  "SIG_FUNS" VARCHAR(1) , 
		  "FUNS" VARCHAR(200) , 
		  "SIG_LMTAMT" VARCHAR(1) , 
		  "LMTAMT" VARCHAR(12) , 
		  "ISOPEN" VARCHAR(1) , 
		  "QUICKADDCASH" VARCHAR(1) )   
		 IN "USERSPACE1" ; 






-- DDL Statements for indexes on Table "ATMP    "."WSUNIT"

CREATE INDEX "ATMP    "."WSUNIT_CHECKIP_INDEX" ON "ATMP    "."WSUNIT" 
		("UNTID" ASC,
		 "NETADDR" ASC,
		 "ISOPEN" ASC)
		
		COMPRESS NO DISALLOW REVERSE SCANS;

-- DDL Statements for indexes on Table "ATMP    "."WSUNIT"

CREATE UNIQUE INDEX "ATMP    "."WSUNIT_INDEX" ON "ATMP    "."WSUNIT" 
		("UNTID" ASC)
		
		COMPRESS NO ALLOW REVERSE SCANS;

------------------------------------------------
-- DDL Statements for table "TCRM    "."WSUNIT"
------------------------------------------------
 

CREATE TABLE "TCRM    "."WSUNIT"  (
		  "UNTID" VARCHAR(8) NOT NULL , 
		  "BRANCHID" VARCHAR(8) , 
		  "SEQNUM" VARCHAR(32) , 
		  "NETADDR" VARCHAR(32) , 
		  "ENABLEDATE" VARCHAR(8) , 
		  "ISOPEN" VARCHAR(1) )   
		 IN "USERSPACE1" ; 


-- DDL Statements for primary key on Table "TCRM    "."WSUNIT"

ALTER TABLE "TCRM    "."WSUNIT" 
	ADD CONSTRAINT "P_Key_1" PRIMARY KEY
		("UNTID");









COMMIT WORK;

CONNECT RESET;

TERMINATE;

