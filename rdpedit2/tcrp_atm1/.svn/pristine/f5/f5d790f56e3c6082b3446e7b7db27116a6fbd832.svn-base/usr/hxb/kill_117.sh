#! /bin/bash

echo "ͣATMCmbu117"
ps -ef | grep atmp | grep bu117.debug | grep -v grep | awk '{print $2}' | xargs kill -s 9
