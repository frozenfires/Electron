#! /bin/bash

if [ -z $1 ]
then
	ikilld=118	
else
	ikilld=$1	
fi

if [ -z $2 ]
then
	isleeptime=100
else
	isleeptime=$2
fi


echo "ͣATMCmbu$ikilld"
ps -ef | grep xatcrp | grep bu$ikilld.debug | grep -v grep | awk '{print $2}' | xargs kill -s 9

./display $isleeptime

echo "start busi$ikilld"
busi30_ora -d bu$ikilld.debug -l 3 -q $ikilld -n busi30_ora_$ikilld &
busi30_ora -d bu$ikilld.debug -l 3 -q $ikilld -n busi30_ora_$ikilld &
busi30_ora -d bu$ikilld.debug -l 3 -q $ikilld -n busi30_ora_$ikilld &
busi30_ora -d bu$ikilld.debug -l 3 -q $ikilld -n busi30_ora_$ikilld &
busi30_ora -d bu$ikilld.debug -l 3 -q $ikilld -n busi30_ora_$ikilld &
