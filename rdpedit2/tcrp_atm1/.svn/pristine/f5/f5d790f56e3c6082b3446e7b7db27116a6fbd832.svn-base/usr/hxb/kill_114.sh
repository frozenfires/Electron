#! /bin/bash

echo "ͣATMCmbu114"
ps -ef | grep atmp | grep bu114.debug | grep -v grep | awk '{print $2}' | xargs kill -s 9
