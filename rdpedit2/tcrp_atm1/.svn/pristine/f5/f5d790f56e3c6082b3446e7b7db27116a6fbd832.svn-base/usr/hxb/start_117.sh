#! /bin/sh

echo "start busi117"
busi30_ora -d bu117.debug -l 3 -q 117 -n busi30_ora_117 &
busi30_ora -d bu117.debug -l 3 -q 117 -n busi30_ora_117 &
busi30_ora -d bu117.debug -l 3 -q 117 -n busi30_ora_117 &
busi30_ora -d bu117.debug -l 3 -q 117 -n busi30_ora_117 &
busi30_ora -d bu117.debug -l 3 -q 117 -n busi30_ora_117 &
