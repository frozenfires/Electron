#! /bin/bash

echo "ͣATMCmbu112"
ps -ef | grep atmp | grep bu102.debug | grep -v grep | awk '{print $2}' | xargs kill -s 9
