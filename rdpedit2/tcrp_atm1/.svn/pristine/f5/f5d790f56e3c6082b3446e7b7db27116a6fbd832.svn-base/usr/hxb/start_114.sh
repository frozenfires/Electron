#! /bin/sh

echo "start busi114"
busi30_ora -d bu114.debug -l 3 -q 114 -n busi30_ora_114 &
busi30_ora -d bu114.debug -l 3 -q 114 -n busi30_ora_114 &
busi30_ora -d bu114.debug -l 3 -q 114 -n busi30_ora_114 &
busi30_ora -d bu114.debug -l 3 -q 114 -n busi30_ora_114 &
busi30_ora -d bu114.debug -l 3 -q 114 -n busi30_ora_114 &
