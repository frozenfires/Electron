
if [ -z $1 ]
then
	echo "FORMAT : $0 <Ŀ¼1> <Ŀ¼2>"
	echo "Etc    : $0 $HOME/dir1/bin $HOME/dir2/bin"
	echo 
	exit
fi
if [ -z $2 ]
then
	echo "FORMAT : $0 <Ŀ¼1> <Ŀ¼2>"
	echo "Etc    : $0 $HOME/dir1/bin $HOME/dir2/bin"
	echo 
	exit
fi
ls -l $1|awk '{print $8}' > /tmp/xx
# ɾ������
sed '/^$/d' /tmp/xx > /tmp/xxx

cat /tmp/xxx | while read LINE
do
	echo "#########  $LINE"
	md5sum $1/$LINE|awk '{print $1}' > /tmp/xx1
	md5sum $2/$LINE|awk '{print $1}' > /tmp/xx2
	diff /tmp/xx1 /tmp/xx2
	echo ""
#	echo "############  Diff $LINE........  #############"
#	diff $1/$LINE $2/$LINE
done
