#!/bin/sh
source /etc/profile
source $HOME/.bash_profile
$HOME/usr/BatchAuto/sendecho
