#include <assert.h>

#include "esb.h"
#include "msp.h"
#include "globle_msp.h"
#include "tsp30.h"
#include "globle_tsp30.h"
#include "OutComm.h"
#include "BalComm.h"
//#include "agent.h"

BalComm         *ptrBalComm;
BalPortStruct   *ptrBalPortStruct;
ApStruct        *ptrApStruct;
DbgStruct       *ptrDbgStruct;
BalPortCfg      *ptrBalPortCur;

char	p_name[32+1];
char	srv_apno[10];
char    dtdBuf[1024*8];

void sig_term(int signo)
{
	esbDebugerr("[%s:%d] %s[%s]", __FILE__, __LINE__, "�յ��ź�", "SIGTERM");
	Msp_Detach_Async();
	exit(0);
}

int main(int argc,char **argv)
{
	int		ch;

	strcpy(sgDebugFile,"sendecho.debug");

	/*ȡ��*/
	while( ( ch = getopt(argc,argv,"l:h") ) != EOF ) 
	{
		switch(ch) 
		{
			case 'l':
				igLogLevel = atoi(optarg);
				break;
			case '?':
			case 'h':
				fprintf(stderr,"Usage:Clear_AsynClear -l <LogLevel 0-product 1-debug>");
				exit(-1);
		}
	}/*end while*/
	
	sigset( SIGHUP , SIG_IGN );
	sigset( SIGCHLD, SIG_IGN );
	sigset( SIGINT , SIG_IGN );
	sigset( SIGALRM, SIG_IGN );
	sigset( SIGQUIT, SIG_IGN );
	sigset( SIGTERM, sig_term);
	
	igLogLevel_src=igLogLevel;
	sprintf(sgDebugFile_src,"%s",sgDebugFile);

	daemon_init();
	
	/*������*/
	if ( TSPMBattach(210) != 0 )
	{
		esbDebug("�󶨶���[210]ʧ��");
		return -1;
	}
	esbLog2("%s", "��ʼ��ȡȡ�ù����ڴ�Get_BalComm");
	if(Get_BalComm()==FAIL)
	{
		esbLogerr("%s", "ȡ�ù����ڴ�ʧ��! EXIT");
		exit(FAIL);
	}
	while(1)
	{
		esbLog2("����ECHO̽�ⱨ�Ŀ�ʼ");
		_FunSendEcho();
		exit(0);
		esbLog2("����ECHO̽�ⱨ�Ľ���");
		sleep(55);
	}

}

int _FunSendEcho()
{
	long	ilTime;
	long	ilmmSec;
	short	ilPrior;
	short	ilClass;
	short	ilType;
	MSGHEAD   *pMsgHead;
	int		rc;
	char sTspTime[7];
	char sTspDate[9];
	char sTspDateTime[11];
	/*��֯ƽ̨�ڲ�����*/

	pMsgHead = (MSGHEAD *) pgCommArea;
	memset(pgCommArea,0,sizeof(pgCommArea));
	memset(sTspTime, 0x00, sizeof(sTspTime));
	memset(sTspDate, 0x00, sizeof(sTspDate));
	memset(sTspDateTime, 0x00, sizeof(sTspDateTime));
	
	/*ƽ̨�ڲ�����ͷ*/
//	strcpy(pMsgHead->aTrncode, "3001");			/*ƽ̨�ڲ�������*/
//	strcpy(pMsgHead->BusiNum, "10002");			    /*ҵ������*/
	strcpy(pMsgHead->Dev_IP, "127.0.0.1");		    /*����IP*/
	
	TSPGetSerno(&(pMsgHead->lTrnid));//���ƽ̨��ˮ��
	pMsgHead->switch_mq =810;
	GetTimess(&ilTime,&ilmmSec);
	pMsgHead->lBegintime = ilTime;
	pMsgHead->lBalBegintime = ilTime;
	pMsgHead->iDestMQ = 210;
	pMsgHead->iMsgClass = 11;
	pMsgHead->iHostType = 0;
	pMsgHead->iFlowPosi = 0;
	pMsgHead->iSwitch_num = 1;
	pMsgHead->Proc_step = 1;
	pMsgHead->iBodylen = 182; //���ĳ���
	pMsgHead->iTrnRevmode = 0;
	pMsgHead->iTrnOverTime = 30;
	pMsgHead->AP_node = 1;
	pMsgHead->BAL_node = 1;
	pMsgHead->cBusiFlag = '5';
	pMsgHead->lCode = 0;
	pMsgHead->iCommEndFlag = 0;
	pMsgHead->iComMQ  = 610;
	pMsgHead->iMsgFormat=2;
	pMsgHead->iSecu_num = 0;
	pMsgHead->iLogLevel = 2;
	pMsgHead->iLogFlag = 1;
	pMsgHead->iSrcMQ = 610;
	pMsgHead->iBegin_MQ_id = 210;

	strncpy(sTspTime, _FunSDATE("HHMMSS"), 6);
	strncpy(sTspDate, _FunSDATE("YYYYMMDD"), 8);
	strncpy(sTspDateTime, sTspDate+4, 4);
	strncpy(sTspDateTime+4, sTspTime, 6);
	sTspDateTime[10]=0;

	/*
	FmlSet("sMsTyp","N",pgCommArea);
	FmlSet("sTraDatTim",sTspDateTime,pgCommArea);
	FmlSet("sSysTraceNo",sTspTime,pgCommArea);
	FmlSet("sSettDate",sTspDate+4,pgCommArea);
	FmlSet("sISTSettDate",sTspDate+4,pgCommArea);
	FmlSet("sTranInsCode","188001",pgCommArea);
	FmlSet("sNetInfoCode","3001",pgCommArea);
	FmlSet("sRevInIDCode","210210",pgCommArea);
	*/

	strcpy( pgCommArea+iMSGHEADLEN, "BCLMALLDEVID2700000000000000000000000000000000                                                 CNY000000000000000000000000000000000000000000000000000000000000000000000000000000000000" );
	tspDebugmsghead(pgCommArea);
	esbDebugStr(pgCommArea+iMSGHEADLEN,pMsgHead->iBodylen);

	ilPrior = 0;
	ilClass = 0;
	ilType = pMsgHead->lTrnid;
	if ((rc=TSPMBwrite(pgCommArea,pMsgHead->iBodylen+iMSGHEADLEN,210,ilPrior,ilClass,ilType)) != 0) 
	{
		esbDebug("������Ϣ������[%d]����", pMsgHead->iDestMQ);
		return;
	}
	esbDebug("������Ϣ������[%d]�ɹ�", pMsgHead->iDestMQ);
}
