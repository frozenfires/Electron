#include "esb.h"
#include "msp.h"
#include "globle_msp.h"
#define BUFFSIZE 128

#define HXB_DEBUG 1 

char PIDPATH[100]={0};
struct msg_buf
{
	int mtype;
	char data[1025];
};
Msp_Proc_Tab 
*p1;//������
unsigned int    ilTmp;
char path[512];
struct msg_buf msgbuf;

int read_cfg(const char *file_name,const char *key,char *value)
{

	FILE *fd;

	fd=fopen(file_name,"r");

	if (fd==NULL) return 1;

	char item[BUFFSIZE];

	memset(item,0,BUFFSIZE);

	int index=0;

	while(fgets(item,BUFFSIZE,fd)!=EOF)
	{

		char *temp=item;

		char *analyze=temp;

		if (*temp=='#') continue;


		int key_start=0,key_end=0,val_start=0,val_end=0,parse=0,parse_locate=0;

		int flag=1;

		while(temp!=EOF&&*temp!='\0'&&*temp!='\n')

		{

			char find_char=*(temp++);

			if (find_char=='=')
			{
				parse++;

				if (parse==1) parse_locate=flag;
			}

			if (find_char!=' '&&!parse)

			{
				if (key_start==0)
				{

					key_start=flag;

					if (*temp=='=') key_end=key_start;

				}
			}

			if (find_char!=' '&&!parse&&key_start)


			{

				key_end=flag;


			}

			if (find_char!=' '&&parse==1&&parse_locate!=flag&&!val_start)
				val_start=flag;

			if (find_char!=' '&&val_start)
				val_end=flag;

			flag++;


		}

		if (key_start*key_end*val_start*val_end)

		{
			int index_tmp;

			char * key_tmp,*val_tmp,*key_result,*val_result;

			int key_len=key_end-key_start+1;

			int val_len=val_end-val_start+1;

			key_tmp=(char *)malloc(key_len);

			val_tmp=(char *)malloc(val_len);

			memset(key_tmp,0,key_len);

			memset(val_tmp,0,val_len);

			key_result=key_tmp;

			val_result=val_tmp;



			for(index_tmp=1;(analyze!=NULL)&&*(analyze)!='\n'&&*(analyze)!='\0';index_tmp++)
			{

				if (index_tmp>=key_start&&index_tmp<=key_end)
					*(key_tmp++)=*analyze;

				if (index_tmp>=val_start&&index_tmp<=val_end)
					*(val_tmp++)=*analyze;

				analyze++;
			}

			if (!strcmp(key,key_result))
			{
				while(val_len--) *(value++)=*(val_result++) ;

				*val_result='\0';

				fclose(fd);

				return 0;
			}



		}

	}


	close(fd);

	return 3;
}



int write_pid()
{
 int fd;
 if ((fd = open(PIDPATH, O_WRONLY | O_TRUNC | O_CREAT, S_IWUSR)) < 0){
      perror("open pidfile faild");
      return -1;
		    }
    struct flock lock;
    lock.l_type = F_WRLCK;
    lock.l_start = 0;
    lock.l_whence = SEEK_SET;
    lock.l_len = 0;
						    
    if (fcntl(fd, F_SETLK, &lock) == -1) {
    int err = errno;
    perror("fcntl faild");
    if (err == EAGAIN) {
    printf("Another process is running now!\n");
        }
      return -1;
	    }    
   return 0;
}



void fun()
{
 system(path);
   
  printf("��Ϣ����ID ��Ϣ���� �����ֽ� ����ֽ� �������ϢPID ��������ϢPID �������Ϣʱ��        ��������Ϣʱ��\n");
  struct msqid_ds buf;
  msgctl(pgPubDsc->iInQueId,IPC_STAT,&buf);
  printf("%5d%8d%8d%12d    %10d     %10d     ",pgPubDsc->iInQueId,buf.msg_qnum,buf.__msg_cbytes,buf.msg_qbytes,buf.msg_lspid,buf.msg_lrpid);
  struct tm *snd = localtime(&buf.msg_stime);
  printf("  %d-%d-%d %d:%d:%d       ",snd->tm_year+1900,snd->tm_mon+1,snd->tm_mday,snd->tm_hour,snd->tm_min,snd->tm_sec);
  struct tm *rcv = localtime(&buf.msg_rtime);
  printf("%d-%d-%d %d:%d:%d\n",rcv->tm_year+1900,rcv->tm_mon+1,rcv->tm_mday,rcv->tm_hour,rcv->tm_min,rcv->tm_sec);
  FILE*fp=fopen("monitor_que.info","at+");
  if(NULL==fp) return;
             time_t rawtime;
             struct tm * t;
             time ( &rawtime );
             t = localtime ( &rawtime );
  fprintf(fp,"��ǰ���ʱ��:%d-%d-%d %d:%d:%d-----------------------------------------\n",t->tm_year+1900,t->tm_mon+1,t->tm_mday,t->tm_hour,t->tm_min,t->tm_sec);
  fprintf(fp,"��Ϣ����ID ��Ϣ���� �����ֽ� ����ֽ� �������ϢPID ��������ϢPID �������Ϣʱ��        ��������Ϣʱ��\n");
  fprintf(fp,"%5d%8d%8d%12d    %10d     %10d     ",pgPubDsc->iInQueId,buf.msg_qnum,buf.__msg_cbytes,buf.msg_qbytes,buf.msg_lspid,buf.msg_lrpid);
  fprintf(fp,"  %d-%d-%d %d:%d:%d       ",snd->tm_year+1900,snd->tm_mon+1,snd->tm_mday,snd->tm_hour,snd->tm_min,snd->tm_sec);
  fprintf(fp,"%d-%d-%d %d:%d:%d\n",rcv->tm_year+1900,rcv->tm_mon+1,rcv->tm_mday,rcv->tm_hour,rcv->tm_min,rcv->tm_sec);

   struct msqid_ds buf2;
   msgctl(pgPubDsc->iOutQueId,IPC_STAT,&buf2);
  printf("%5d%8d%8d%12d    %10d     %10d     ",pgPubDsc->iOutQueId,buf2.msg_qnum,buf2.__msg_cbytes,buf2.msg_qbytes,buf2.msg_lspid,buf2.msg_lrpid);
  struct tm*snd2=localtime(&buf2.msg_stime) ;
  printf("  %d-%d-%d %d:%d:%d        ",snd2->tm_year+1900,snd2->tm_mon+1,snd2->tm_mday,snd2->tm_hour,snd2->tm_min,snd2->tm_sec);
  struct tm *rcv2 = localtime(&buf2.msg_rtime);
  printf("  %d-%d-%d %d:%d:%d\n",rcv2->tm_year+1900,rcv2->tm_mon+1,rcv2->tm_mday,rcv2->tm_hour,rcv2->tm_min,rcv2->tm_sec);
  fprintf(fp,"%5d%8d%8d%12d    %10d     %10d     ",pgPubDsc->iOutQueId,buf2.msg_qnum,buf2.__msg_cbytes,buf2.msg_qbytes,buf2    .msg_lspid,buf2.msg_lrpid);
  fprintf(fp,"  %d-%d-%d %d:%d:%d        ",snd2->tm_year+1900,snd2->tm_mon+1,snd2->tm_mday,snd2->tm_hour,snd2->tm_min,snd2->tm_sec);
fprintf(fp,"  %d-%d-%d %d:%d:%d\n",rcv2->tm_year+1900,rcv2->tm_mon+1,rcv2->tm_mday,rcv2->tm_hour,rcv2->tm_min,rcv2->tm_sec);
   printf("������� ��һ����λ�� ����PID  ����λ��   �����    ������    ��ǰ�ʼ�/����ʼ�\n");
   fprintf(fp,"������� ��һ����λ�� ����PID  ����λ��   �����    ������    ��ǰ�ʼ�/����ʼ�\n");
  ilTmp = pgPubDsc->iFstUsdProc;
  while(ilTmp != pgPubDsc->iMaxAttachNum)
  {
   p1 = (Msp_Proc_Tab *)(pgProcHead + ilTmp*sizeof(Msp_Proc_Tab));
   printf("%3d %12d %10d%10d    ",ilTmp,p1->iNextPosi,p1->iUserPid,p1->iMbIdPosi);
   Msp_Mb_Tab* pp =(Msp_Mb_Tab *)(pgMbHead + p1->iMbIdPosi*sizeof(Msp_Mb_Tab));
   printf(" %4d   %10.10s %8d/%d\n",pp->iMbId,pp->sMbName,pp->iMailNum,pp->iMaxMailNum);
   fprintf(fp,"%3d %12d %10d%10d    ",ilTmp,p1->iNextPosi,p1->iUserPid,p1->iMbIdPosi);
   fprintf(fp," %4d   %10.10s %8d/%d\n",pp->iMbId,pp->sMbName,pp->iMailNum,pp->iMaxMailNum);
   ilTmp = p1->iNextPosi;
  }
fclose(fp);
}

void init_sig(void)
{
struct sigaction act;
act.sa_handler = fun;
act.sa_flags =0;
sigemptyset(&act.sa_mask);
sigaction(SIGALRM,&act,NULL);
}

void init_time(int v)
{
 struct itimerval value;
 value.it_value.tv_sec = 0;
 value.it_value.tv_usec=1;
 value.it_interval.tv_sec =v;
 value.it_interval.tv_usec=0;
 setitimer(ITIMER_REAL,&value,NULL);
}


short	igLogLevel;
main(int argc,char **argv)
{
	   
	   char value[20];
      
	   memset(value,0,20);
//     int flag=read_cfg("monitor.cfg","TIMEVAL",value);

//	 if (flag==1) printf("open cofig file monitor.cfg error");
  //   int n = atoi(value);

	unsigned char *plTmp;
	char	slPath[400];
	key_t	ShmKey;
    int ret = 0;
	igBusId = 2;
	if(getenv("MSP_DIR")== NULL) 
	{
	   fprintf(stderr,"Not Set MSP_DIR!\n");
	   exit(-1);
	}
	snprintf(sgMspPath,sizeof(sgMspPath),"%s",getenv("MSP_DIR"));

	//snprintf(slPath,sizeof(slPath),"%s/log/maillog/%d",sgMspPath,igBusId);
	snprintf(slPath,sizeof(slPath),"%s/etc/ipckey/maillog/%d",sgMspPath,igBusId);
#ifdef HXB_DEBUG
	printf( "DEBUG:slPath=[%s]\n",slPath );
#endif
	memset(PIDPATH,0,sizeof(PIDPATH));
	snprintf(PIDPATH,sizeof(PIDPATH),"%s/bin/monitor.lock",sgMspPath);
	     if (write_pid() < 0) //����ͬʱ�ж���ó���������
	       return -1;
 	ShmKey = ftok(slPath,1);
 	if(ShmKey == (key_t)-1)
 	{
 	fprintf(stderr,"ERROR:attach ftok ShmKey error reason:[%s]\n",
 	strerror(errno));
     exit(0);
    }
		if((ret =(unsigned char*)shmget(ShmKey,0,0)) == -1)
				{
							printf("ϵͳδ���� !\n");
									exit(0);
				}
    snprintf(path,sizeof(path),"%s/bin/mymonitor.sh",sgMspPath);

    plTmp = shmat(ret,NULL,0);
	pgPubDsc = (Msp_Pub_Tab *)plTmp;
     
	  int flag=read_cfg("monitor.cfg","TIMEVAL",value);
      if (flag==1) 
	  {
		  printf("open cofig file monitor.cfg error\n");
         exit(-1);
	}
      int n = atoi(value);

    pgMbHead = shmat(pgPubDsc->iMailShmId,(char *)0, SHM_RND);
    pgProcHead = pgMbHead + pgPubDsc->iToProc;//������������ַ
	 FILE*fp=fopen("monitor_que.info","at+");
	 char ch;
	 if(fp)
    {
	  ch=fgetc(fp);
	  if(ch==EOF)
	  {
		  time_t rawtime; 
		  struct tm * t; 
		  time ( &rawtime ); 
		  t = localtime ( &rawtime ); 

	    fprintf(fp,"----------create monitor_que.info file success----------\n");
		fprintf(fp,"%d-%d-%d %d:%d:%d\n",t->tm_year+1900,t->tm_mon+1,t->tm_mday,t->tm_hour,t->tm_min,t->tm_sec);
		fprintf(fp,"This file is record monitor TSP's que and process's mail information\n");
 
	  }
	 fclose(fp);
	}
    init_sig();
    init_time(n);
    while(1);
return 0;
}

