/*
	File   :esb.h
	Author :Huqizhu <louise_hu@m165.com>
	date   :20070513
	address:PeiKing
	Comments: for esb
*/
#include	<assert.h>
#include	<stdio.h>
#include	<sys/types.h>
#include	<sys/socket.h>
#include	<netinet/in.h>
#include	<string.h>
#include	<arpa/inet.h>
#include	<stdlib.h>
#include	<unistd.h>
#include	<errno.h>
#include	<pwd.h>
#include	<grp.h>
#include	<sys/stat.h>
#include	<sys/ipc.h>
#include	<sys/sem.h>
#include	<sys/msg.h>
#include	<sys/shm.h>
#include 	<fcntl.h>
#include 	<sys/file.h>
#include 	<sys/time.h>
#include	<sys/signal.h>
#include	<signal.h>
#include	<setjmp.h>
#include  <dirent.h>
#include  <limits.h>

#ifdef LINUX
#include 	<stdarg.h>
#endif
#ifdef AIX
#include 	<varargs.h>
#endif
#include	<time.h>
#include	<sys/timeb.h>
#include	<netdb.h>

#include <ctype.h>
#include <malloc.h>
#include <memory.h>
#include <math.h>
#include <libgen.h>
#include <sys/param.h>
#include <sys/sysmacros.h>
#include <sys/mman.h>

#include <sys/ioctl.h>
#ifdef AIX
#include <sys/conf.h> /*fro AIX*/
#endif
#include <sys/wait.h>

#ifndef _ESB_H
#define _ESB_H 1
/********************ESB ��������**********************/
#define RESERVE       	'1'	     /*������*/
#define UNRESERVE       '0'	     /*���󲻱���*/
/********************ESB ��������**********************/
/********************ESB struct define**********************/
typedef struct{
	long mtype;
	unsigned char	mtext[512];
}EsbMsg;
typedef struct
{
	unsigned long iPackUnused;     /*δ�ÿռ���ָ��*/
	unsigned int iUnusedStore;     /*δ�ÿռ��С*/
	unsigned short iMailPackSize;  /*MailPack�ṹ��С*/
	unsigned short iPackHeadSize;  /*PackHead�ṹ��С*/
}PackHead;

typedef struct{
	unsigned int iLength;
	unsigned long lNextPosi;
	unsigned long lPrePosi;
	unsigned int iPackLength;
}MailPack;

/********************ESB struct define**********************/
/*
return code config
AXXXX
A:1--ESB;2--MSP;3--TSP;
*/
/********************ESB������*************************/
#define ESBTRUE		1	/*��*/
#define ESBFALSE	0       /*��*/
#define	ESBSUCCESS	10000   /*�ɹ�*/
#define	ESBFAIL		10001   /*ʧ��*/
#define BUFSMALL        10002   /*��ű��ĵĿռ�̫С*/
#define STRNULL		10003   /*�ַ���Ϊ��*/
#define READTIMEOUT	10004	/*��ʱ*/
/********************ESB������*************************/


/*define Process area */
int	InitPackMem(char *,int);
int 	WritePackMem ( char *, int , char *, unsigned int, unsigned long *);
int	ReadPackMem( char *,int, char *,char ,unsigned int *,unsigned long);
int	DelPackMem( char *, int	, unsigned long );
int	DisplUnusdPackMem( char *);
int	DisPackDetail( char *, unsigned long );
char	*CreateShm( key_t , int *, unsigned int );
char    *CreateMmapShm(const char *path, char *addr, size_t size);
unsigned short 	DeleteShm(int);
unsigned short 	CreateMsg(key_t , int *);
unsigned short 	DeleteMsg(int );
void		ClearMsg(int,long);
unsigned short	SendMsg(int,EsbMsg *,int);
unsigned short  RcvMsg(int,EsbMsg *,int *,int);
unsigned short 	CreateSem(key_t , int *);
unsigned short 	DeleteSem(int );
void 		*shmGet( key_t );
int		ESBP(int);
int		ESBV(int);
static	void	(*func)();
void		t_catch();
#ifdef AIX
/*int esbDebug(char *frm, va_dcl);*/      /*del by hrn 20080522*/
#endif
#ifdef SCO
int esbDebug(char *frm, va_dcl);
#endif
#ifdef LINUX
int esbDebug(char *frm, ...);
#endif
int     esbDebughex(char * ,short );
int     esbDebugStr(char * ,short );
int     esbDebugStrRaw(char * ,short );
int	StrReverse( char s[]);
int	StrLtoA(long,char s[]);
int	StrCmp(char *,char *);
int	StrReplace(char *,char *,char *,char *);
int	_Transfer(char *,short,char *);
int	_Untransfer(char *,char *,short *);
int	StrTrim(char *,char);
char*	StrTrim0(char *);

static void	 (*Signal(int sig, void (*func)(int)))(int);
char	*strftimeval(char *s, const char *fmt, const struct timeval *tp, int flag);
int		 DaemonInit(void);
/*Process area sources*/


/********************ESB Global define**********************/
extern char	sgDebugFile[256];
extern EsbMsg	esbmsg;
long	igTrnid;
extern short	igLogLevel;

#endif /*_ESB_H*/
