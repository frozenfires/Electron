#!/bin/sh
#dtpath=$TSP_DIR/bin
#cd $dtpath
if [ ! -e monitor_pro.info ]                                          
then
 touch monitor_pro.info                                            
  echo "----------create monitor_pro.information file success----------" > monitor_pro.info
   echo $(date +%Y"."%m"."%d" "%k":"%M":"%S) >> monitor_pro.info 
    echo "this file is record monitor TSP's process information" >> monitor_pro.info
	fi  
	
busi1=(`awk -F'=' '$1~/BUSIIDONE/{print $2}' monitor.cfg`)
if [ "$busi1" = "" ]
then
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)   "BUSIIDONE is not set!">>monitor_pro.info
exit 1
fi
busi2=(`awk -F'=' '$1~/BUSIIDTWO/{print $2}' monitor.cfg`)
if [ "$busi2" = "" ]
then
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)    "BUSIIDTWO is not set!">>monitor_pro.info
exit 1
fi
busi3=(`awk -F'=' '$1~/BUSIIDTHR/{print $2}' monitor.cfg`)
if [ "$busi3" = "" ]
then
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)   "BUSIIDTHR is not set!">>monitor_pro.info
exit 1
fi
busi4=(`awk -F'=' '$1~/BUSIIDFOUR/{print $2}' monitor.cfg`)
if [ "$busi4" = "" ]
then
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)   "BUSIIDFOUR is not set!">>monitor_pro.info
exit 1
fi
channelin=(`awk -F'=' '$1~/CHANNELIN/{print $2}' monitor.cfg`)
if [ "$channelin" = "" ]
then
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)   "CHANNELIN is not set!">>monitor_pro.info
exit 1
fi
channelout=(`awk -F'=' '$1~/CHANNELOUT/{print $2}' monitor.cfg`)
if [ "$channelout" = "" ]
then
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)   "CHANNELOUT is not set!">>monitor_pro.info
exit 1
fi
srvport=(`awk -F'=' '$1~/SRVPORT/{print $2}' monitor.cfg`)
if [ "$srvport" = "" ]
then
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)   "SRVPORT is not set!">>monitor_pro.info
exit 1
fi
cliport=(`awk -F'=' '$1~/CLIPORT/{print $2}' monitor.cfg`)
if [ "$cliport" = "" ]
then
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)   "CLIPORT is not set!">>monitor_pro.info
exit 1
fi
timeval=(`awk -F'=' '$1~/TIMEVAL/{print $2}' monitor.cfg`)
if [ "$timeval" = "" ]
then
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)   "TIMEVAL is not set!">>monitor_pro.info
exit 1
fi
#while true
#do

NUM1=$(psw|grep busi30_ora|grep -v "grep"|grep $busi1|wc -l)
if [ $NUM1 = "1" ];
then
echo "busi$busi1    is ok"
else
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)  "busi30_ora_$busi1 Process is dead">>monitor_pro.info 
busi30_ora  -d bu$busi1.debug -l $loglevel -n busi30_ora_$busi1 -q $busi1 &
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)   "restart busi30_ora_$busi1 Process">>monitor_pro.info
fi

NUM2=$(psw|grep busi30_ora|grep -v "grep"|grep $busi2|wc -l)
if [ $NUM2 = "1" ];
then
echo "busi$busi2    is ok"
else
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)  "busi30_ora_$busi2 Process is dead">>monitor_pro.info
busi30_ora  -d bu$busi2.debug -l $loglevel -n busi30_ora_$busi2 -q $busi2 &
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)   "restart busi30_ora_$busi2 Process">>monitor_pro.info
fi

 NUM3=$(psw|grep busi30_ora|grep -v "grep"|grep $busi3|wc -l)
  if [ $NUM3 = "1" ];
    then
   echo "busi$busi3    is ok"
   else
   echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)  "busi30_ora_$busi3 Process is dead">>monitor_pro.info
   busi30_ora  -d bu$busi3.debug -l $loglevel -n busi30_ora_$busi3 -q $busi3 &
   echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)   "restart busi30_ora_$busi3 Process">>monitor_pro.info
   fi

 NUM4=$(psw|grep busi30_ora|grep -v "grep"|grep $busi4|wc -l)
if [ $NUM4 = "1" ];
then
echo "busi$busi4    is ok"
else
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)  "busi30_ora_$busi4 Process is dead">>monitor_pro.info
busi30_ora  -d bu$busi4.debug -l $loglevel -n busi30_ora_$busi4 -q $busi4 &
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)   "restart busi30_ora_$busi4 Process">>monitor_pro.info
fi

NUM5=$(psw |grep switch_ora|grep -v "grep"|wc -l)
if [ $NUM5 = "1" ];
then
echo "switch     is ok"
else
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)  "switch_ora Process is dead">>monitor_pro.info
switch_ora -d sw.debug -n switch_ora -l $loglevel &
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)   "restart switch_ora Process">>monitor_pro.info
fi


NUM6=$(psw|grep channel30_ora|grep -v "grep" | grep $channelin|wc -l)
if [ $NUM6 = "1" ];
then
echo "channel$channelin is ok"
else
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)  "channel30_ora_$channelin Process is dead">>monitor_pro.info
channel30_ora -l $loglevel -c $channelin -i 1 -n channel30_ora_$channelin &
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)   "restart channel130_ora_$channelin Process">>monitor_pro.info
fi


 NUM7=$(psw|grep channel30_ora|grep -v "grep" | grep $channelout|wc -l)
 if [ $NUM7 = "1" ];
 then
 echo "channel$channelout is ok"
 else
 echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)  "channel30_ora_$channelout Process is dead">>monitor_pro.info
 channel30_ora -l $loglevel -c $channelout -i 1 -n channel30_ora_$channelout &
 echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)   "restart channel30_ora_$channelout Process">>monitor_pro.info
fi


NUM8=$(psw |grep WorkLog30_ora|grep -v "grep"|wc -l)
if [ $NUM8 = "2" ];
then
echo "WorkLog    is ok"
else
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)  "WorkLog30_ora Process is dead">>monitor_pro.info
killname WorkLog30_ora
WorkLog30_ora -d WorkLog.debug  -l $loglevel &
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)   "restart WorkLog30_ora Process">>monitor_pro.info
fi

NUM9=$(psw |grep Bal2AP_Srv30|grep -v "grep"|wc -l)
if [ $NUM9 = "1" ];
then
echo "Bal2AP_Srv30 is ok"
else
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)  "Bal2AP_Srv30 Process is dead">>monitor_pro.info
Bal2AP_Srv30 -l $loglevel &
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)   "restart Bal2AP_Srv30 Process">>monitor_pro.info
fi

NUM10=$(psw |grep BalCommSrv30|grep -v "grep"|grep $srvport|wc -l)
if [ $NUM10 = "2" ];
then
echo "BalCommSrv30 is ok"
else
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)  "BalCommSrv30 -l $loglevel -p $srvport Process is dead">>monitor_pro.info
killname BalCommSrv30
BalCommSrv30 -l $loglevel -p $srvport -d BalCommSrv30_$srvport.debug &
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)   "restart BalCommSrv30 -l $loglevel -p $srvport Process">>monitor_pro.info
fi

NUM11=$(psw |grep CommClientSA|grep -v "grep"|grep $cliport|wc -l)
if [ $NUM11 = "1" ];
then
echo "CommClientSA is ok"
else
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)  "CommClientSA_SL30 -l $loglevel -m $cliport Process is dead">>monitor_pro.info
CommClientSA_SL30 -l $loglevel -m $cliport -d CommClientSA_$cliport_2.debug &
echo $(date +%Y"."%m"."%d" "%k":"%M":"%S)   "restart CommClientSA_SL30 -l $loglevel -m $cliport Process">>monitor_pro.info
fi

#sleep $timeval
#done;
