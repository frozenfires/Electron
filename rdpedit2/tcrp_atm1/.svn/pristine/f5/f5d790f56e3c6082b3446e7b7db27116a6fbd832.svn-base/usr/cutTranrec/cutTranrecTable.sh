#!/bin/bash

source /etc/profile
source $HOME/.bash_profile

echo "##########################################"
echo `date`

$HOME/usr/cutTranrec/bin/cuttranrectable

echo `date`
