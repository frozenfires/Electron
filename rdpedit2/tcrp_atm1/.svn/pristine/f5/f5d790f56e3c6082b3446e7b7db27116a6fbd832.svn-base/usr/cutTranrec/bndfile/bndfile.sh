#!/bin/bash
db2 connect to $BASESERV user $DBUSER using $DBPASSWD
db2 bind cuttranrectable.bnd
