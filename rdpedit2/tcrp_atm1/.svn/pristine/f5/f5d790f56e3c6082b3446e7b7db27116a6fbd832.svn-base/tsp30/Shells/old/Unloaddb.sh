cd $HOME
. ./.profile
if [ ! -d $HOME/dbbak/data/unl ]
then
        mkdir -p $HOME/dbbak/data/unl 
fi
cd $HOME/dbbak/data/unl
dbaccess  $BASESERVBUSI << --!
unload to "m20_cardtable.unl" select * from  m20_cardtable;
unload to "m20_unit.unl" select * from  m20_unit;
unload to "m20_cashbox.unl" select * from  m20_cashbox;
unload to "m20_atmkey.unl" select * from  m20_atmkey;
unload to "m20_transkey.unl" select * from  m20_transkey;
unload to "m20_deskey.unl" select * from  m20_deskey;
unload to "m20_msg.unl" select * from  m20_msg;
unload to "m20_msgexch.unl" select * from  m20_msgexch;
unload to "m20_branch_f.unl" select * from  m20_branch_f;
unload to "m20_ccbs_teller.unl" select * from  m20_ccbs_teller;
--!
dbaccess  $BASESERV << --!
unload to "m02_combalance.unl" select * from  m02_combalance;
unload to "m02_tcpsrv_portcfg.unl" select * from  m02_tcpsrv_portcfg;
unload to "m02_ap_info.unl" select * from  m02_ap_info;
unload to "m02_tcpcli_portcfg.unl" select * from  m02_tcpcli_portcfg;
unload to "m02_comout.unl" select * from  m02_comout;
unload to "m01_mq.unl" select * from  m01_mq;
--!
cd $HOME/dbbak/data/unl 
rm -f ./*.tar*
bakfile=busidata`date +%Y%m%d`.tar
tar cvf  ${bakfile} ./*.unl
compress ${bakfile} 
rm -f ./*.unl
