#!/bin/sh
#
# Copyright (C) 1988-2010, Nantian Co., Ltd.
#
# $Id: startout.sh,v 1.2 2010/11/04 15:12:52 mymtom Exp $
#
# $Log: startout.sh,v $
# Revision 1.2  2010/11/04 15:12:52  mymtom
# REL_1_2
#
# Revision 1.1.1.1  2010/08/14 20:19:29  cvsadmin
# Initial import
#
# Revision 1.2  2010/08/02 10:37:38  mymtom
# Add to CVS
#
#
 
outcomm.sh start
sleep 5 

exit 0
