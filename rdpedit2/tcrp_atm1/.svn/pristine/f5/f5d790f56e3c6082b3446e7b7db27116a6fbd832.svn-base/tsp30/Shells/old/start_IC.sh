	level=1
	BUSY_LIST="106 126 137 147"
	
	CHANNEL_LIST="206 407"
	
	SECU_LIST="857"
	
	SWITCH_LIST="806"
		
		for BUSY_ID in $BUSY_LIST;do
        echo "*start busi$BUSY_ID"
	busi30_ifx -d bu$BUSY_ID.debug -l $level -q $BUSY_ID -n busi30_ifx_$BUSY_ID &
	busi30_ifx -d bu$BUSY_ID.debug -l $level -q $BUSY_ID -n busi30_ifx_$BUSY_ID &
	sleep 1
        done                            
	                                          
	                                          
	                                          
         for SECU_ID in $SECU_LIST;do
        echo "*start secu$SECU_ID"
        #secu30_ifx -d  secu$SECU_ID.debug -l $level -n secu30_ifx_$SECU_ID &
        secu30_ifx -m $SECU_ID -l $level
	sleep 1
        done
          for SWITCH_ID in $SWITCH_LIST;do
	echo "*start switch$SWITCH_ID"
	switch_ifx -m $SWITCH_ID -l $level
	sleep 1
	done
	                       
	                                          
for CHANNEL_ID in $CHANNEL_LIST;do
        echo "*start channel$CHANNEL_ID"
	if [ $CHANNEL_ID -ne 406 ]; then
		channel30_ifx -c $CHANNEL_ID -m $CHANNEL_ID -l $level -i 0 -n channel30_ifx_$CHANNEL_ID
	else
		channel30_ifx -c $CHANNEL_ID -m $CHANNEL_ID -l $level -i 1 -n channel30_ifx_$CHANNEL_ID
	fi
	sleep 1
        done
        
           echo "*start channel407"
	     channel30_ifx -c 407 -m 511 -l $level -i 0 -n channel30_ifx_407511 &
	     channel30_ifx -c 407 -m 512 -l $level -i 0 -n channel30_ifx_407512 &
	     channel30_ifx -c 407 -m 513 -l $level -i 0 -n channel30_ifx_407513 &
	     channel30_ifx -c 407 -m 514 -l $level -i 0 -n channel30_ifx_407514 &
	     channel30_ifx -c 407 -m 516 -l $level -i 0 -n channel30_ifx_407516 &
	     
	sleep 1
