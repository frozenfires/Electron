#!/bin/sh


startap.sh
sleep 2

startout.sh
sleep 2

startbal.sh
sleep 2

echo "TCRP�汾��" `cat $VERFILE`

exit 0
~            
