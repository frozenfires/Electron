#!/bin/sh
umask 002
checkipc()
{
	printf "%s:%s\n" $1 `ftok $1 1` >> $log
	key=`ftok $1 1`
	ipcs | awk 'BEING {
			flag=0;
		}
		flag==0 && ($1=="m" || $1=="s" || $1=="q") {
			if (substr($3, 5, 6) == substr("'${key}'", 5, 6)) {
				flag = 1;
			}
		}
		END {
			exit flag;
		}'
}

dup=0
log=/home/nfic30/log/checkipc.log

mspknl -d2
sleep 2
killname mspknl
sleep 1
killname -9 mspknl
sleep 1

cd $HOME/etc/ipckey/
# echo "ԭ����ǰ�Ľڵ�ֵ"
date "+%Y-%m-%d %H:%M:%S" | tee -a $log
ls -ild maillog/2 comm trnlog | tee -a $log

checkipc $HOME/etc/ipckey/maillog/2
if [ $? -eq 1 ]; then
   dup=1
   echo "ftok $HOME/etc/ipckey/maillog/2 �ļ�ֵ���ظ�" | tee -a $log
	mv $HOME/etc/ipckey/maillog/2 $HOME/etc/ipckey/maillog/2.bak
	mkdir -p $HOME/etc/ipckey/maillog/2
fi

checkipc $HOME/etc/ipckey/comm
if [ $? -eq 1 ]; then
   dup=1
   echo "ftok $HOME/etc/ipckey/comm �ļ�ֵ���ظ�" | tee -a $log
	mv $HOME/etc/ipckey/comm $HOME/etc/ipckey/comm.bak
	mkdir -p $HOME/etc/ipckey/comm 
fi

checkipc $HOME/etc/ipckey/trnlog
if [ $? -eq 1 ]; then
   dup=1
   echo "ftok $HOME/etc/ipckey/trnlog �ļ�ֵ���ظ�" | tee -a $log
	mv $HOME/etc/ipckey/trnlog $HOME/etc/ipckey/trnlog.bak
	mkdir -p $HOME/etc/ipckey/trnlog 
fi


if [ "atmphout" = "$LOGNAME" ]
then
	checkipc $HOME/dcc/node/$LOCAL_BANK_ID
	if [ $? -eq 1 ]; then
		dup=1
		echo "ftok $HOME/dcc/node/$LOCAL_BANK_ID �ļ�ֵ���ظ�" | tee -a $log
	fi

fi


if [ $dup -eq 0 ]; then
	echo "δ��⵽�ظ���IPC��ֵ" | tee -a $log
fi

echo "====" >> $log
echo "" >> $log
