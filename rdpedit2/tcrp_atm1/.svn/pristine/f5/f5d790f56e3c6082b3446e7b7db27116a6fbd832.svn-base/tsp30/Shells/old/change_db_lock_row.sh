#�����ݿ������б�����ģʽ��Ϊ�м���
#Usage:change_db_lock_row.sh dbname

#���ر���
#lv_dbname

if [ ! $# -eq 1 ]
then
  echo "Usage:$0 dbname!"
  exit
fi

lv_dbname=$1

echo "start.."

dbaccess - -<<! 2>/dev/null 1>&2
database ${lv_dbname};
unload to lock_row.tmp select tabname from systables where tabid > 99 and tabtype = 'T';
!
if [ ! $? -eq 0 ]
then
    echo "Database ${lv_dbname} is not exist or have no permission!"
    exit
fi
sed "s/\|/ lock mode (row)\;/" lock_row.tmp > lock_row1.tmp
sed "s/^/alter table /" lock_row1.tmp > lock_row2.tmp

lv_filename="change_db_lock_row_exec.sh"
rm -f ${lv_filename}

echo "dbaccess - -<<!" >> ${lv_filename}
echo "database ${lv_dbname};" >> ${lv_filename}
cat lock_row2.tmp >> ${lv_filename}
echo "!" >> ${lv_filename}

sh change_db_lock_row_exec.sh 2>/dev/null 1>&1

echo "over.."
