#!/bin/sh
#
# $Id: filekeep.sh,v 1.2 2011/07/06 06:53:40 mymtom Exp $
#
# $Log: filekeep.sh,v $
# Revision 1.2  2011/07/06 06:53:40  mymtom
# 1.2
#
# Revision 1.1.2.1  2011/06/08 07:51:09  Samlee
# �������°汾��filekeep.sh
#
# Revision 1.0  2010/05/26 08:34:32  atmph
# Initial revision
#
#

##
# @file		filekeep.sh
# @brief	lookup file with size > sizemax and move to logbak
##


# 32768 * 512 = 16MB
trap "" HUP
size=32768
sdir=$HOME/log/debug
ddir=$HOME/log/logbak
fpid=$HOME/log/debug/.filekeep.pid
min_count=10000
max_count=10000
#����ļ���ǰ10000�е���С��ˮ��
trnid_min()
{
	head -${min_count} $1 | awk '
	BEGIN {
		curr = "[999999999]";
	}
	$1 ~ /\[[1-9][0-9]{8}\]/ {
		if ($1 < curr) {
			curr = $1
		}
	}
	END {
		print substr(curr, 2, 9);
	}
	'
}
#����ļ��к�10000�е������ˮ��
trnid_max()
{
	tail -${max_count} $1 | awk '
	BEGIN {
		curr = "[000000000]";
	}
	$1 ~ /\[[1-9][0-9]{8}\]/ {
		if ($1 > curr) {
			curr = $1
		}
	}
	END {
		print substr(curr, 2, 9);
	}
	'
}

if [ -r ${fpid} -a -s ${fpid} ]; then
	kill -s TERM `cat ${fpid}`
	true > ${fpid}
fi

if [ "$1" = "stop" ]; then
	exit 0
fi

echo $$ > ${fpid}

cd ${HOME}
# simple way to avoid wildcard error if no matched file

while [ 0 ]; do
	list=""
	list="${list} ${sdir}/*.debug*"
	list="${list} ${sdir}/*.[Ll][Oo][Gg]"
	list="${list} ${sdir}/[0-9]*_[0-9]*_[0-9]*_[0-9]*"
	list="${list} ${HOME}/log/frntCall.log"
	date=`date "+%Y%m%d%H%M"`
	for file in ${list}; do
		if [ -e ${file} ]; then
			d=`dirname ${file}`
			f=`basename ${file}`
			min=`trnid_min $file`
			max=`trnid_max $file`
			find ${d} -name ${f} -size +${size} -exec mv {} ${ddir}/${f}-${min}-${max}-${date} ';'
		fi
	done
    nice find log/logbak log/logcom -type f > log/loglist.txt
	sleep 120
done


