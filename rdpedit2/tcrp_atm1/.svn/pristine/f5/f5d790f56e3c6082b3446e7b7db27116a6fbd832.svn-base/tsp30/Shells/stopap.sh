#!/bin/sh
#
# Copyright (C) 1988-2010, Nantian Co., Ltd.
#
# $Id: stopap.sh,v 1.2 2010/11/04 15:12:52 mymtom Exp $
#
# $Log: stopap.sh,v $
# Revision 1.2  2010/11/04 15:12:52  mymtom
# REL_1_2
#
# Revision 1.1.1.1  2010/08/14 20:19:29  cvsadmin
# Initial import
#
# Revision 1.2  2010/08/02 10:37:38  mymtom
# Add to CVS
#
# Revision 1.0  2010/05/06 07:24:56  atmphuat
# Initial revision
#
#

#echo "ap logout"
#APLogin -o
#sleep 10

echo "����ͣTCRC�������"
ps -ef | grep bu101.debug | grep -v grep | awk '{print $2}' | xargs kill -s 9
sleep 1

echo "ͣ����ͨѶ����"
ps -ef | grep BalCommSrv30_8007 | grep -v grep | awk '{print $2}' | xargs kill -s 9
sleep 1


killname AP2Bal_Cli30
killname AP2Out_Cli30

echo "\a stop channel30"
killname channel30_ora

echo "\a stop busi30_ora"
killname busi30_ora

echo "\a stop secu30_ora"
killname secu30_ora

echo "\a stop switch_ora"
killname switch_ora

echo "\a stop worklog30"
killname worklog30

#echo "\a stop APMonitor"
killname APMonitor
#killname APTimer

#echo "\a stop SysMon"
#killname MonAgent
#killname MonProxy
#killname JrnlGen
#killname JrnlTran
#killname MonCommSrv
killname JrnlGet

# killname ltfserv

#cd $HOME/bin
#echo "\a stop ChcfileSendSrv"
#killname ChcfileSendSrv

#killname AP2Bal_Cli30
#killname AP2Out_Cli30

#sleep 5

#datasync -u -v m20_cardtable      >> $TSP_DEBUG_PATH/datasync.debug 
#datasync -u -v m20_conf_curr      >> $TSP_DEBUG_PATH/datasync.debug
#datasync -u -v m20_conf_notes     >> $TSP_DEBUG_PATH/datasync.debug
#datasync -u -v m20_conf_dcccode   >> $TSP_DEBUG_PATH/datasync.debug
#datasync -u -v m20_conf_lckinfo   >> $TSP_DEBUG_PATH/datasync.debug
#datasync -u -v m20_msgexch        >> $TSP_DEBUG_PATH/datasync.debug
#datasync -u -v m09_sys_mon_config >> $TSP_DEBUG_PATH/datasync.debug
#datasync -u -v m06_busiway        >> $TSP_DEBUG_PATH/datasync.debug
shmmon30 -d

OutStat -u

sleep 1
#filekeep.sh stop

pid=`ps -u $LOGNAME -o user,pid,comm | awk '$3 ~ /^switch|^BalComm|^CommClient/{print}'`
if [ -z "$pid" ]; then
	echo "stopping mspknl ..."
	sleep 5
	mspknl -d 2
fi

exit 0
