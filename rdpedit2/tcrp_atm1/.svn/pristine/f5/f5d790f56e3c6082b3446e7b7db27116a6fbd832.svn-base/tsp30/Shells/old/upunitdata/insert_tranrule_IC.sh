#!/bin/sh
echo "��ʼ����IC��ҵ����tranrule��"

dbaccess  tsp30_sit << --!
insert into m02_tranrule (branch_f, trncode, port_chnl, ap_list, err_code, err_max) values ('***      ', '203800    ', 206, '*', '#', 0);
insert into m02_tranrule (branch_f, trncode, port_chnl, ap_list, err_code, err_max) values ('***      ', '203810    ', 206, '*', '#', 0);
insert into m02_tranrule (branch_f, trncode, port_chnl, ap_list, err_code, err_max) values ('***      ', '203812    ', 206, '*', '#', 0);
insert into m02_tranrule (branch_f, trncode, port_chnl, ap_list, err_code, err_max) values ('***      ', '203820    ', 206, '*', '#', 0);
insert into m02_tranrule (branch_f, trncode, port_chnl, ap_list, err_code, err_max) values ('***      ', '203821    ', 206, '*', '#', 0);
insert into m02_tranrule (branch_f, trncode, port_chnl, ap_list, err_code, err_max) values ('***      ', '203822    ', 206, '*', '#', 0);
insert into m02_tranrule (branch_f, trncode, port_chnl, ap_list, err_code, err_max) values ('***      ', '203830    ', 206, '*', '#', 0);
insert into m02_tranrule (branch_f, trncode, port_chnl, ap_list, err_code, err_max) values ('***      ', '203833    ', 206, '*', '#', 0);
insert into m02_tranrule (branch_f, trncode, port_chnl, ap_list, err_code, err_max) values ('***      ', '203840    ', 206, '*', '#', 0);
insert into m02_tranrule (branch_f, trncode, port_chnl, ap_list, err_code, err_max) values ('***      ', '203850    ', 206, '*', '#', 0);
insert into m02_tranrule (branch_f, trncode, port_chnl, ap_list, err_code, err_max) values ('***      ', '203851    ', 206, '*', '#', 0);
insert into m02_tranrule (branch_f, trncode, port_chnl, ap_list, err_code, err_max) values ('***      ', '203855    ', 206, '*', '#', 0);
insert into m02_tranrule (branch_f, trncode, port_chnl, ap_list, err_code, err_max) values ('***      ', '203860    ', 206, '*', '#', 0);
insert into m02_tranrule (branch_f, trncode, port_chnl, ap_list, err_code, err_max) values ('***      ', '201121    ', 204, '*', '#', 0);
!
