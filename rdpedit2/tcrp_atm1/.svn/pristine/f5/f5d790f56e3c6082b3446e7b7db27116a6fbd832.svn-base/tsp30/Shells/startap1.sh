#!/bin/sh
#
# Copyright (C) 1988-2010, Nantian Co., Ltd.
#
# $Id: startap.sh,v 1.2 2010/11/04 15:12:48 mymtom Exp $
#
# $Log: startap.sh,v $
# Revision 1.2  2010/11/04 15:12:48  mymtom
# REL_1_2
#
# Revision 1.1.1.1  2010/08/14 20:19:29  cvsadmin
# Initial import
#
# Revision 1.2  2010/08/02 10:37:37  mymtom
# Add to CVS
#
# Revision 1.1  2010/05/06 06:16:13  mymtom
#
# Revision 1.0  2010/04/21 10:45:54  mymtom
# Initial revision
#
#

level=3

sys_mon_start()
{
	mq=`awk -F"[ \t]+" '
		BEGIN { head = 0;tail = 0; }
		head == 1 && $1 == "[END]" { tail=1; }
		head == 1 && tail == 0 && NF == 7 { print $1; }
		$1 == "[MAILBOXCFG]" { head=1; }' $MSP_DIR/etc/mspsrv.cfg`
	MonProxy   -l $level &
	sleep 1
	MonAgent   -l $level -i 300 $mq &
	sleep 1

	JrnlGen    -l $level -i 60
	JrnlTran   -l $level -i 60 -s 64.0.98.32 -p 31119
	MonCommSrv -l $level -p 22420 -a

	filekeep.sh start > /dev/null 2>&1 &
	# (cd $ATMPHFILE/moni  && ltfserv)
}

pid=`ps -u $LOGNAME -o user,pid,comm | awk '"mspknl"==$3{print $2}'`
if [ -z "$pid" ]; then
	echo "start msp"
	startmsp
fi

cd $HOME/bin
umask 002

echo "begin Init Share Memory now!"
shmmon30 -i

echo "start busi111"
busi30_ora -d bu111.debug -l $level -q 111 -n busi30_ora_111 &
#busi30_ora -d bu111.debug -l $level -q 111 -n busi30_ora_111 &
#busi30_ora -d bu111.debug -l $level -q 111 -n busi30_ora_111 &
#busi30_ora -d bu111.debug -l $level -q 111 -n busi30_ora_111 &
sleep 1
echo "start busi112"
busi30_ora -d bu112.debug -l $level -q 112 -n busi30_ora_112 &
#busi30_ora -d bu112.debug -l $level -q 112 -n busi30_ora_112 &
#busi30_ora -d bu112.debug -l $level -q 112 -n busi30_ora_112 &
#busi30_ora -d bu112.debug -l $level -q 112 -n busi30_ora_112 &
sleep 1
echo "start busi113"
busi30_ora -d bu113.debug -l $level -q 113 -n busi30_ora_113 &
#busi30_ora -d bu113.debug -l $level -q 113 -n busi30_ora_113 &
#busi30_ora -d bu113.debug -l $level -q 113 -n busi30_ora_113 &
#busi30_ora -d bu113.debug -l $level -q 113 -n busi30_ora_113 &
sleep 1
echo "start busi114"
busi30_ora -d bu114.debug -l $level -q 114 -n busi30_ora_114 &
#busi30_ora -d bu114.debug -l $level -q 114 -n busi30_ora_114 &
#busi30_ora -d bu114.debug -l $level -q 114 -n busi30_ora_114 &
#busi30_ora -d bu114.debug -l $level -q 114 -n busi30_ora_114 &
sleep 1
echo "start busi115"
busi30_ora -d bu115.debug -l $level -q 115 -n busi30_ora_115 &
#busi30_ora -d bu115.debug -l $level -q 115 -n busi30_ora_115 &
#busi30_ora -d bu115.debug -l $level -q 115 -n busi30_ora_115 &
#busi30_ora -d bu115.debug -l $level -q 115 -n busi30_ora_115 &
sleep 1
echo "start busi116"
busi30_ora -d bu116.debug -l $level -q 116 -n busi30_ora_116 &
#busi30_ora -d bu116.debug -l $level -q 116 -n busi30_ora_116 &
#busi30_ora -d bu116.debug -l $level -q 116 -n busi30_ora_116 &
#busi30_ora -d bu116.debug -l $level -q 116 -n busi30_ora_116 &
sleep 1
echo "start busi121"
busi30_ora -d bu121.debug -l $level -q 121 -n busi30_ora_121 &
#busi30_ora -d bu121.debug -l $level -q 121 -n busi30_ora_121 &
#busi30_ora -d bu121.debug -l $level -q 121 -n busi30_ora_121 &
#busi30_ora -d bu121.debug -l $level -q 121 -n busi30_ora_121 &
sleep 1
echo "start busi122"
busi30_ora -d bu122.debug -l $level -q 122 -n busi30_ora_122 &
#busi30_ora -d bu122.debug -l $level -q 122 -n busi30_ora_122 &
#busi30_ora -d bu122.debug -l $level -q 122 -n busi30_ora_122 &
#busi30_ora -d bu122.debug -l $level -q 122 -n busi30_ora_122 &
sleep 1

echo "start secu841"
secu30_ora -d  secu.debug -m 841 -l $level -n secu30_ora_841 &
#secu30_ora -d  secu.debug -m 841 -l $level -n secu30_ora_841 &
#secu30_ora -d  secu.debug -m 841 -l $level -n secu30_ora_841 &
#secu30_ora -d  secu.debug -m 841 -l $level -n secu30_ora_841 &
sleep 1

echo "start secu851"
secu30_ora -d  secu.debug -m 851 -l $level -n secu30_ora_851 &
#secu30_ora -d  secu.debug -m 851 -l $level -n secu30_ora_851 &
#secu30_ora -d  secu.debug -m 851 -l $level -n secu30_ora_851 &
#secu30_ora -d  secu.debug -m 851 -l $level -n secu30_ora_851 &
sleep 1


echo "start switch810"
switch_ora -d    sw.debug -m 810 -l $level -n switch_ora_810 &
#switch_ora -d    sw.debug -m 810 -l $level -n switch_ora_810 &
#switch_ora -d    sw.debug -m 810 -l $level -n switch_ora_810 &
#switch_ora -d    sw.debug -m 810 -l $level -n switch_ora_810 &
sleep 1



echo "start channel210"
channel30_ora -c 210 -m 210 -l $level -i 0 -n channel30_ora_210 &
#channel30_ora -c 210 -m 210 -l $level -i 0 -n channel30_ora_210 &
#channel30_ora -c 210 -m 210 -l $level -i 0 -n channel30_ora_210 &
#channel30_ora -c 210 -m 210 -l $level -i 0 -n channel30_ora_210 &
sleep 1

echo "start channel220"
channel30_ora -c 220 -m 220 -l $level -i 0 -n channel30_ora_220 &
#channel30_ora -c 220 -m 220 -l $level -i 0 -n channel30_ora_220 &
#channel30_ora -c 220 -m 220 -l $level -i 0 -n channel30_ora_220 &
#channel30_ora -c 220 -m 220 -l $level -i 0 -n channel30_ora_220 &
sleep 1

echo "start channel420"
channel30_ora -c 420 -m 420 -l $level -i 0 -n channel30_ora_420 &
#channel30_ora -c 420 -m 420 -l $level -i 0 -n channel30_ora_420 &
#channel30_ora -c 420 -m 420 -l $level -i 0 -n channel30_ora_420 &
#channel30_ora -c 420 -m 420 -l $level -i 0 -n channel30_ora_420 &
sleep 1

echo "start channel421"
channel30_ora -c 421 -m 421 -l $level -i 0 -n channel30_ora_421 &
#channel30_ora -c 421 -m 421 -l $level -i 0 -n channel30_ora_421 &
#channel30_ora -c 421 -m 421 -l $level -i 0 -n channel30_ora_421 &
#channel30_ora -c 421 -m 421 -l $level -i 0 -n channel30_ora_421 &
sleep 1

echo "start channel430"
channel30_ora -c 430 -m 430 -l $level -i 0 -n channel30_ora_430 &
#channel30_ora -c 430 -m 430 -l $level -i 0 -n channel30_ora_430 &
#channel30_ora -c 430 -m 430 -l $level -i 0 -n channel30_ora_430 &
#channel30_ora -c 430 -m 430 -l $level -i 0 -n channel30_ora_430 &
sleep 1

echo "start channel440"
channel30_ora -c 440 -m 440 -l $level -i 1 -n channel30_ora_440 &
#channel30_ora -c 440 -m 440 -l $level -i 1 -n channel30_ora_440 &
#channel30_ora -c 440 -m 440 -l $level -i 1 -n channel30_ora_440 &
#channel30_ora -c 440 -m 440 -l $level -i 1 -n channel30_ora_440 &
sleep 1

echo "start WorkLog"
worklog30 -d WorkLog.debug  -l $level -p 5 -n worklog30 &
#worklog30 -d WorkLog.debug  -l $level -p 5 -n worklog30 &

echo "start APMonitor"
APMonitor -d APMonitor.debug -l $level -n APMonitor &
#APTimer   -d APTimer.debug   -l $level

#echo "start JrnlGet"
#JrnlGet -m 599 -f 5 &

sleep 1 

#AP2Out_Cli30 -l $level -n AP2Out_Cli30 &
#AP2Bal_Cli30 -l $level -n AP2Bal_Cli30 &

#echo "ATMP�汾��"
#cat $VERFILE
 
exit 0
