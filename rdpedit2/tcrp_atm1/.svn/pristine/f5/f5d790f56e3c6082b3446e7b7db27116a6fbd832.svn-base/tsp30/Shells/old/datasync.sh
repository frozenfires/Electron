#��������������ű�
#create at 2011-06-27

datasync -s M09_SYS_MON_CONFIG | grep 1\|401
datasync -s M09_SYS_MON_CONFIG | grep 1\|402
datasync -s M09_SYS_MON_CONFIG | grep 1\|403
datasync -s M09_SYS_MON_CONFIG | grep 1\|404
datasync -s M09_SYS_MON_CONFIG | grep 1\|405
datasync -s M09_SYS_MON_CONFIG | grep 1\|406
datasync -s M09_SYS_MON_CONFIG | grep 1\|501
datasync -s M09_SYS_MON_CONFIG | grep 1\|502
datasync -s M09_SYS_MON_CONFIG | grep 1\|503
datasync -s M09_SYS_MON_CONFIG | grep 1\|504
datasync -s M09_SYS_MON_CONFIG | grep 1\|505
datasync -s M09_SYS_MON_CONFIG | grep 1\|506
