#!/bin/sh
substr()
{
    awk 'BEGIN {print substr("'$1'", "'$2'", "'$3'")}' < /dev/null
}

sent_keep_dead=$1
shift
for file in $*; do
	echo $file
	if [ "x`substr $file 1 4`" = "xjrnl" -a 0`substr $file 9 8` -lt 0$sent_keep_dead ]
	then
		ls -l ${file} | filerecord
		rm -f $file
	fi
done
