cd $HOME
. ./.profile
Y=`date +"%y%m%d%H"`

echo "Begin to Backup TSP30 ,Date="$Y
exp nfic3tsp30/nfic3tsp30@oracle file=$HOME/backup/tsp30db_$Y.dmp owner=nfic3tsp30
exp nfic3sitbusi/nfic3sitbusi@oracle file=$HOME/backup/tspbusi30db_$Y.dmp owner=nfic3sitbusi
tar cvf $HOME/backup/tsp30_gz_$Y.tar .profile Makefile Makefile.defines Makefile.oracle Makefile.informix \
		msp public30 usrc30 tsp30 inc30 uinc30 etc 

cd $HOME/backup

mkdir $HOME/backup/$Y
compress tsp30db_$Y.dmp
compress tspbusi30db_$Y.dmp
compress tsp30_gz_$Y.tar

mv tsp30db_$Y.dmp.Z $HOME/backup/$Y
mv tspbusi30db_$Y.dmp.Z $HOME/backup/$Y
mv tsp30_gz_$Y.tar.Z $HOME/backup/$Y

echo "Backup TSP30 over"
