#!/bin/sh
#
# Copyright (C) 1988-2010, Nantian Co., Ltd.
#
# $Id: outcomm.sh,v 1.2 2010/11/04 15:12:46 mymtom Exp $
#
# $Log: outcomm.sh,v $
# Revision 1.2  2010/11/04 15:12:46  mymtom
# REL_1_2
#
# Revision 1.1.1.1  2010/08/14 20:19:29  cvsadmin
# Initial import
#
# Revision 1.2  2010/08/02 10:37:37  mymtom
# Add to CVS
#
# Revision 1.0  2010/05/06 07:22:29  atmphuat
# Initial revision
#
#

outcomm_start()
{
	pid=`ps -u $LOGNAME -o user,pid,ppid,vsz,comm | awk '"mspknl"==$5{print $2}'`
	if [ -z "$pid" ]; then
		startmsp
	fi
	cd $HOME/bin
	echo "starting outcomm ..."
#	Out2AP_Srv30 -l 2 &
	sleep 1

	CommClientSA_SL30 -l 3 -m 706 -n CommClientSA_SL30_706 -d CommClientSA_SL30_706.debug &
	CommClientSA_SL30 -l 3 -m 707 -n CommClientSA_SL30_707 -d CommClientSA_SL30_707.debug &
#	CommClientSA_SL30 -l 3 -m 705 -n CommClientSA_SL30_705 -d CommClientSA_SL30_705.debug &
#	CommClientSA_SL30 -l 3 -m 722 -n CommClientSA_SL30_722 -d CommClientSA_SL30_722.debug &
#	CommClientSA_SL30 -l 3 -m 730 -n CommClientSA_SL30_730 -d CommClientSA_SL30_730.debug &
#	CommClientSA_SL30 -l 3 -m 740 -n CommClientSA_SL30_740 -d CommClientSA_SL30_740.debug &

	sleep 1
}

outcomm_stop()
{
	echo "stopping outcomm ..."

	killname Out2AP_Srv30
	sleep 1

	killname CommClientSA_SL
	sleep 1

	pid=`ps -u $LOGNAME -o user,pid,comm | awk '$3 ~ /^switch|^BalComm|^CommClient/{print}'`
	if [ -z "$pid" ]; then
		sleep 1
		mspknl -d 2
	fi

	Out2AP_Srv30 -u
	sleep 1
}

case "$1" in
start)
	outcomm_start
	;;
stop )
	outcomm_stop
	;;
""|restart)
	outcomm_stop
	sleep 2
	outcomm_start
	;;
esac

