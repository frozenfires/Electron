#!/bin/sh

balcomm.sh stop
sleep 2

outcomm.sh stop
sleep 2


#echo "ap logout"
#APLogin -o
#sleep 10

killname AP2Bal_Cli30
killname AP2Out_Cli30

echo "\a stop channel30"
killname channel30_ora

echo "\a stop busi30_ora"
killname busi30_ora

echo "\a stop secu30_ora"
killname secu30_ora

echo "\a stop switch_ora"
killname switch_ora

echo "\a stop worklog30"
killname worklog30

echo "\a stop APMonitor"
killname APMonitor

shmmon30 -d

OutStat -u

sleep 1
#filekeep.sh stop

pid=`ps -u $LOGNAME -o user,pid,comm | awk '$3 ~ /^switch|^BalComm|^CommClient/{print}'`
if [ -z "$pid" ]; then
        echo "stopping mspknl ..."
        sleep 3 
        mspknl -d 2
fi

exit 0
         
