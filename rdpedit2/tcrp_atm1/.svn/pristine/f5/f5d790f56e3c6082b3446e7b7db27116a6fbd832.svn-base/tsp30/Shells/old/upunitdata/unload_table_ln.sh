if [ 1 -ne $# ]
then
    "usage:unload_dev.sql ���ݿ���"
    exit 0
fi

mkdir devdata
cd devdata

echo "��ʼ����������ATMP���ݿ���Ϣ"

dbaccess $1 <<!
unload to estermini.txt
select etstermid,merno,deviceno,bankid,"210000000",termid,ipaddr,port,
       suport,area,purchasedate, hosttermid0,hosttermid1,hosttermid2,
       hosttermid3,localfunc,acpfog,chkacc,pinidx,macidx,termarea,tag
from estermini;

unload to ccbs_teller.txt
select "210000000",branch_teller,term_id,seq_id,flag,substr((CAST(teller_seq AS INTEGER) +11000000)||'',2,7) AS teller_seq_x,u_flag
from ccbs_teller;


unload to evatmperiod.txt
select "210000000",etstermid,regflag,period,newpinkey,newmackey,oldpinkey,oldmackey,
        atmtmkkey,starttime,endtime,tag
from evatmperiod;
!


echo "�������ݳɹ�";

tar -cvf devdata.tar ./*.txt
mv devdata.tar ../devdata.tar
cd -
rm -rf devdata
