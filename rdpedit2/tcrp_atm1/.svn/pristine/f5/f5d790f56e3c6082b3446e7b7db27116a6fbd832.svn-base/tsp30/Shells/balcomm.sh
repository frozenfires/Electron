#!/bin/sh
#
# Copyright (C) 1988-2010, Nantian Co., Ltd.
#
# $Id: balcomm.sh,v 1.2 2010/11/04 15:12:42 mymtom Exp $
#
# $Log: balcomm.sh,v $
# Revision 1.2  2010/11/04 15:12:42  mymtom
# REL_1_2
#
# Revision 1.1.1.2  2010/09/30 11:55:34  Samlee
# ����5���˿��ṩATMC��������
#
# Revision 1.1.1.1  2010/08/14 20:19:29  cvsadmin
# Initial import
#
# Revision 1.3  2010/08/02 10:48:14  wlx
# chmod o+r
#
# Revision 1.2  2010/08/02 10:37:37  mymtom
# Add to CVS
#
# Revision 1.0  2010/05/06 07:22:29  atmphuat
# Initial revision
#
#

level=2

balcomm_start()
{
	pid=`ps -u $LOGNAME -o user,pid,comm | awk '"mspknl"==$3{print $2}'`
	if [ -z "$pid" ]; then
		startmsp
	fi

	echo "starting balcomm ..."

	cd $HOME/bin

	Bal2AP_Srv30  -l $level -n Bal2AP_Srv30 &
	sleep 5 

	
	
	BalCommSrv30  -l $level -p 8007 -n BalCommSrv30_8007 -d BalCommSrv30_8007.debug &
	sleep 1
}

balcomm_stop()
{
	echo "stopping balcomm ..."

	killname Bal2AP_Srv30
	killname BalCommSrv30

	sleep 2

	pid=`ps -u $LOGNAME -o user,pid,comm | awk '$3 ~ /^switch|^BalComm|^CommClient/{print}'`
	if [ -z "$pid" ]; then
		sleep 1
		mspknl -d 2
	fi
	Bal2AP_Srv30 -u
}

case "$1" in
start)
	balcomm_start
	;;
stop )
	balcomm_stop
	;;
""|restart)
	balcomm_stop
	sleep 2
	balcomm_start
	;;
esac



