FF=`ipcs -m | grep nfic30 | cut -c2-11`
for f in $FF
do 
   ipcrm -m $f
done
FF=`ipcs -q | grep nfic30 | cut -c2-11`
for f in $FF
do 
   ipcrm -q $f
done
FF=`ipcs -s | grep nfic30 | cut -c2-11`
for f in $FF
do 
   ipcrm -s $f
done
