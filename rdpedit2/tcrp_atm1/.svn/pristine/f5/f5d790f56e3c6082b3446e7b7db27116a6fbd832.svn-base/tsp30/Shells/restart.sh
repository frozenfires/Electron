cd $HOME
stoptcrp.sh
starttcrp.sh
