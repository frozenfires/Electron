#!/bin/bash

source /etc/profile
source $HOME/.bash_profile

cd $HOME
Y=`date +"%Y%m%d%H%M"`
path=$HOME/backup/log
file=$path/atmp_log_$Y.tar.gz

mkdir -p $path

echo "Begin To Backup Log, File="$file

tar -zcvf $file $HOME/log/debug/*debug* $HOME/log/unionhsm.log

rm -f $HOME/log/debug/*debug*
rm -f $HOME/log/unionhsm.log


echo "Backup Log Successful"
