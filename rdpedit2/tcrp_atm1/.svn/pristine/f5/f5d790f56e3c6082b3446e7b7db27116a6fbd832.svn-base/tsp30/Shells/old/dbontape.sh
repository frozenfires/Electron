INFORMIXDIR=/home/db/informix/ids11.50
ONCONFIG=onconfig.atmphdb
INFORMIXSERVER=atmphdb
PATH=$INFORMIXDIR/bin:$PATH
export INFORMIXDIR ONCONFIG INFORMIXSERVER PATH

ln=`onstat - 2>/dev/null|grep "On-Line -- Up"`
[ "$ln" ] || {
        echo "You must execute this file on DB machine, or the database is not start. Exit"
        exit
}

MON=`date|tr -s " "|cut -f2 -d " "`
DAT=`date|tr -s " "|cut -f3 -d " "`
YER=`date|tr -s " "|cut -f6 -d " "`
DATE=${YER}${MON}${DAT}
BACKUPDIR=/home/backup

[ ! -d $BACKUPDIR ] && {
        echo "Can't find $BACKUPDIR. Exit"
        exit
}

rm -f $BACKUPDIR/*.atmphdb* 2>/dev/null

touch $BACKUPDIR/db.atmphdb
chmod 777 $BACKUPDIR/db.atmphdb
chown atmphap1:informix $BACKUPDIR/db.atmphdb

touch $BACKUPDIR/log.atmphdb
chmod 777 $BACKUPDIR/log.atmphdb
chown atmphap1:informix $BACKUPDIR/log.atmphdb

onmode -l

echo `date`
echo "Execute ontape command ......\n"
echo ` ` | ontape -s -L 0
[ $? -ne 0 ] && {
        echo "ontape fail. Exit"
        exit
}||{
        echo "ontape success"
}
echo `date`
onstat -d > $BACKUPDIR/onstat.atmphdb$DATE


cd $BACKUPDIR
cp $INFORMIXDIR/etc/$ONCONFIG onconfig.atmphdb$DATE
cp $INFORMIXDIR/etc/sqlhosts sqlhosts.atmphdb$DATE
mv db.atmphdb db.atmphdb$DATE
cp log.atmphdb log.atmphdb$DATE
compress db.atmphdb$DATE

echo "Database backup copy success"

echo "Database ontape backup complete. Success"
