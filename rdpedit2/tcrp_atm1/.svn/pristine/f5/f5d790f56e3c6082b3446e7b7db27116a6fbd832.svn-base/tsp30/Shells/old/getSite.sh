rm -f $HOME/log/getSite.tar.Z
errpt -a > $HOME/log/errpt.log
ps -ef > $HOME/log/ps-ef.log
ipcs -a > $HOME/log/ipcs.log
dumpknl -b2 > $HOME/log/dumpknl.log
tar -cvf $HOME/log/getSite.tar $HOME/log/*.log
compress $HOME/log/getSite.tar
rm -f $HOME/log/*.log
