#!/bin/sh

sh  filter_unit.sh  untid.txt  estermini.txt  ccbs_teller.txt  evatmperiod.txt ln
