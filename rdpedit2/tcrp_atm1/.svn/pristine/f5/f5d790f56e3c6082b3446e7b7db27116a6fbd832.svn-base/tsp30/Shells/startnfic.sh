#!/bin/sh

level=3

pid=`ps -u $LOGNAME -o user,pid,comm | awk '"mspknl"==$3{print $2}'`
if [ -z "$pid" ]; then
        startmsp
fi

cd $HOME/bin
umask 002

echo "begin Init Share Memory now!"
shmmon30 -i

echo "start busi104"
busi30_ora -d bu104.debug -l $level -q 104 -n busi30_ora_104 &
sleep 1

echo "start busi103"
#busi30_ora -d bu103.debug -l $level -q 103 -n busi30_ora_103 &
sleep 1

echo "start busi105"
busi30_ora -d bu105.debug -l $level -q 105 -n busi30_ora_105 &
sleep 1

echo "start busi109"
#busi30_ora -d bu109.debug -l $level -q 109 -n busi30_ora_109 &
sleep 1

echo "start busi107"
#busi30_ora -d bu107.debug -l $level -q 107 -n busi30_ora_107 &
sleep 1

echo "start secu841"
#secu30_ora -d  secu.debug -m 841 -l $level -n secu30_ora_841 &
sleep 1

echo "start channel204" 
#channel30_ora -c 204 -m 204 -l $level -i 0 -n channel30_ora_204 &
sleep 1

echo "start channel205" 
channel30_ora -c 205 -m 205 -l $level -i 0 -n channel30_ora_205 &
sleep 1

echo "start channel200" 
channel30_ora -c 200 -m 200 -l $level -i 1 -n channel30_ora_200 &
sleep 1

echo "start channel402" 
channel30_ora -c 402 -m 402 -l $level -i 1 -n channel30_ora_402 &
sleep 1

echo "start channel403" 
#channel30_ora -c 403 -m 403 -l $level -i 0 -n channel30_ora_403 &
sleep 1

echo "start channel405" 
#channel30_ora -c 405 -m 405 -l $level -i 0 -n channel30_ora_405 &
sleep 1

echo "start switch800"
switch_ora -d    sw.debug -m 800 -l $level -n switch_ora_800 &
sleep 1


echo "start WorkLog"
worklog30 -d WorkLog.debug  -l $level -p 5 -n worklog30 &

echo "start APMonitor"
APMonitor -d APMonitor.debug -l $level -n APMonitor &

AP2Out_Cli30 -l $level -n AP2Out_Cli30 &
AP2Bal_Cli30 -l $level -n AP2Bal_Cli30 &

outcomm.sh start
sleep 2

balcomm.sh start
sleep 2

echo "ATMP2.0�汾��"
cat $VERFILE

exit 0
~            
