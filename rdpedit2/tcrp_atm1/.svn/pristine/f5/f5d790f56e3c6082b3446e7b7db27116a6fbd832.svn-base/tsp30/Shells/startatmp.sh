#!/bin/sh


startap.sh
sleep 2

startout.sh
sleep 2

startbal.sh
sleep 2

echo "ATMP�汾��" `cat $VERFILE`

exit 0
~            
