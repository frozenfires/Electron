# 
# Copyright (C), 1988-2011, Nantian Co., Ltd.
#
# $Id: profile_host.sh,v 1.2.2.1 2011/07/04 08:39:00 mymtom Exp $
#

export ORACLE_BASE=/home/db/oracle
export ORACLE_HOME=/home/db/oracle/product/10.2.0
export ORACLE_SID=atmphdb
export TUXDIR=/home/mw/tuxedo/tuxedo10gR3
export WSNADDR=//128.192.62.227:8180,//128.192.62.228:8180


if [ -f $HOME/.kshrc -a -r $HOME/.kshrc ]; then
	ENV=$HOME/.kshrc            # set ENV if there is an rc file
	export ENV
fi

# PATH
export PATH=/usr/bin:/etc:/usr/sbin:/usr/local/bin
export PATH=$PATH:/usr/ucb:/usr/bin/X11:/sbin:/usr/DynamicLinkManager/bin
export PATH=$PATH:/usr/vac/bin:/home/FortifySoftware/SCAS-EE4.5.0
export PATH=$PATH:/opt/rational/clearcase/bin
export PATH=$PATH:$ORACLE_HOME/bin:.
# For database
export BASESERV=atmphdb
export BASESERVBUSI=atmphdb

# For Informix
export INFORMIXSERVER=online_atmph
export INFORMIXDIR=/home/db/informix
export ONCONFIG=onconfig.atmph
export INFORMIXSQLHOSTS=$HOME/etc/sqlhosts.atmph
export TERMCAP=$INFORMIXDIR/etc/termcap
export PATH=$PATH:$INFORMIXDIR/bin
#export DB_LOCALE=zh_cn.gb
#export CLIENT_LOCALE=zh_cn.gb
export DBDATE=Y4MD/
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$INFORMIXDIR/lib:$INFORMIXDIR/lib/esql
export INFORMIXTERM=terminfo
export DBEDIT=vi

# For dynamic library
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$HOME/lib30:$HOME/ulib30:$HOME/local/lib
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$ORACLE_HOME/lib
export LIBPATH=$LD_LIBRARY_PATH

# for MSP
MSP_NODE_ID=2
MSP_DIR=$HOME
MSP_PORT=6500
MSP_BUS_ID=2
MSP_GROUP_ID=2
PATH=$PATH:$MSP_DIR/bin
export MSP_NODE_ID MSP_DIR MSP_PORT MSP_BUS_ID MSP_GROUP_ID PATH
# Set up ESB
# ����ˮ�ź�ϵͳ����SHMIDʹ��
ESB_DEBUG_PATH=$HOME/log/debug
export ESB_DEBUG_PATH

# Set up TSP
# ����ˮ�ź�ϵͳ����SHMIDʹ��
TSP_DIR=$HOME
TSP_DEBUG_PATH=$HOME/log/debug
TSP_NODE_ID=2
TSP_SAF_TIME=10
TSP_GATE_TIME=100
TSP_TASK_TIME=1800
TSP_LOG_PATH=$HOME/log/trnlog
# ƽ̨��������
TSP_REV_NUM=3
# ����ʱ����(��)
TSP_REV_TIME=600
export TSP_DIR TSP_DEBUG_PATH TSP_NODE_ID TSP_SAF_TIME TSP_TASK_TIME
export TSP_GATE_TIME TSP_LOG_PATH TSP_REV_NUM TSP_REV_TIME
export PATH=$PATH:$TSP_DIR/bin
export VERFILE=$HOME/etc/ver/ver.ini

# AP & OUT
export BRANCH_CODE=010000000
export AP_NODE_ID=1
export TSP_COMOUT_ID=1
export TSP_COMBAL_ID=1

# sec log env
export SWITCH_DEBUG_PATH=$HOME/log/debug

# 
# DCC ��������
# 
DCCNAME=����
export DCCNAME
FRONTDIR=$HOME/dcc
SECDIR=$HOME/dcc
SELFKEY=12
FCLOG_PRIORITY=DEBUG
export FRONTDIR SECDIR SELFKEY
export PATH=$PATH:$SECDIR/bin
export FCLOG_PRIORITY
export REMOTE_BANK_ID="010000000X"
# export LOCAL_BANK_ID=ATMPHAP001
export LOCAL_BANK_ID=440600716L
export LOGPATH=$HOME

export PS1=`hostname`"-"'$PWD'">"
set -o vi
alias rm='rm -i'
alias l='ls -l'
alias cdlog='cd $HOME/log/debug'

# 
# TUXEDO����
export CC=cc
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$TUXDIR/lib
export LIBPATH=$TUXDIR/lib:$LIBPATH
NLS_PATH=$TUXDIR/locale/C;export NLS_PATH
LANG=C;export LANG
export PATH=$PATH:$TUXDIR/bin
export ULOGPFX=$HOME/log/debug
#export TUXCONFIG=$HOME/etc/tuxconfig
export FLDTBLDIR32=$HOME/etc/agent
export FLDTBLDIR=$HOME/etc/agent

export FIELDTBLS32=AgentFields
export FIELDTBLS=AgentFields

LANG=C;export LANG
export ULOGPFX=$HOME/log/debug

export FLDTBLDIR32=$HOME/etc/agent
export FLDTBLDIR=$HOME/etc/agent

export FIELDTBLS32=AgentFields
export FIELDTBLS=AgentFields

# ATMPHҵ�񻷾�����
#
# ��ȡ�ļ�������Ŀ¼
export ATMPHFILE=/home/ap/atmphfile
export AP_LOG_DIR=$HOME/log
export AP_CFG_DIR=$HOME/etc

# ������ض��йص��ļ�Ŀ¼
export MONI_FILE_PATH=$ATMPHFILE/moni
# ����ָ���ļ���V�˵�ָ��Ŀ¼
# export DATA_P2V_PATH=/home/ap/webatmv/WEB-INF/file/fileCatch
export DATA_P2V_PATH=$ATMPHFILE

# ��Ŷ����ļ���Ŀ¼
export CHKACC_FILE=$ATMPHFILE/chkacc
# ���Ͷ����ļ���V�˵�ָ��Ŀ¼
#export DATA_CHKACC_PATH=/home/ap/webatmv/WEB-INF/file/accounts
export DATA_CHKACC_PATH=$ATMPHFILE

# �Ĵ�����ҵ�񷵻��ļ����·������P��
export DATA_HOSPITAL_PATH=$ATMPHFILE/sichuan/hospital

# �Ĵ�����ҵ�񷵻��ļ����·������P��
export OLD_DATA_HOSPITAL_PATH=/home/ap/switch/file/hospital

# �⿨ͳһȫ�е�33����
export FSFBSM=010000000

# ���������ļ�
export CONFIG_PATH_JIJIN=$HOME/etc/fundfile.conf
export DETAIL_PATH_JIJIN=$HOME/etc/atm/fundpaper.txt

export FRT_FILEDIR=$ATMPHFILE/frt
export PRINTERDIR=$ATMPHFILE/detail
export DCC_MX_TOTAL=100
export FSERVCFG=$HOME/etc/atm

# ��־�����ñ���
export TSP_LOG_BACK=$HOME/log/logbak
export TSP_LOG_BACK_TMP=$HOME/log/logbak/logbaktmp

# �趨��ɾ���ļ��ı�������
export LOG_KEEP_DAYS=7
export FRT_KEEP_DAYS=2
export HOS_KEEP_DAYS=2

# �������ݿ���û�����������ܺ�Ĵ��·��
export DBCONFIG=$HOME/etc

# ORACLE charset
export NLS_LANG="SIMPLIFIED CHINESE_CHINA.ZHS16GBK"

export NMON=ct
umask 002

# lllib trace setting
export LL_TRACE_FLAG=ON
export LL_TRACE_LEVEL=4
export LL_TRACE_PATH=$HOME/log

if [ -r $HOME/ubb/tux.env ]; then
	. $HOME/ubb/tux.env
fi
