echo "kill all resources....."
FF=`ipcs -m | grep tsp30 | cut -c11-18`
for f in $FF
do 
   ipcrm -m $f
done
FF=`ipcs -q | grep tsp30 | cut -c11-18`
for f in $FF
do 
   ipcrm -q $f
done
FF=`ipcs -s | grep tsp30 | cut -c11-18`
for f in $FF
do 
   ipcrm -s $f
done
