#!/bin/sh
#
# Copyright (C) 1988-2010, Nantian Co., Ltd.
#
# $Id: stopbal.sh,v 1.2 2010/11/04 15:12:54 mymtom Exp $
#
# $Log: stopbal.sh,v $
# Revision 1.2  2010/11/04 15:12:54  mymtom
# REL_1_2
#
# Revision 1.1.1.1  2010/08/14 20:19:29  cvsadmin
# Initial import
#
# Revision 1.2  2010/08/02 10:37:38  mymtom
# Add to CVS
#
#

balcomm.sh stop
sleep 2

exit 0
