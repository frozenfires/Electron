#!/bin/sh
#
# Copyright (C) 1988-2010, Nantian Co., Ltd.
#
# $Id: startap.sh,v 1.2 2010/11/04 15:12:48 mymtom Exp $
#
# $Log: startap.sh,v $
# Revision 1.2  2010/11/04 15:12:48  mymtom
# REL_1_2
#
# Revision 1.1.1.1  2010/08/14 20:19:29  cvsadmin
# Initial import
#
# Revision 1.2  2010/08/02 10:37:37  mymtom
# Add to CVS
#
# Revision 1.1  2010/05/06 06:16:13  mymtom
#
# Revision 1.0  2010/04/21 10:45:54  mymtom
# Initial revision
#
#

level=3

sys_mon_start()
{
	mq=`awk -F"[ \t]+" '
		BEGIN { head = 0;tail = 0; }
		head == 1 && $1 == "[END]" { tail=1; }
		head == 1 && tail == 0 && NF == 7 { print $1; }
		$1 == "[MAILBOXCFG]" { head=1; }' $MSP_DIR/etc/mspsrv.cfg`
	MonProxy   -l $level &
	sleep 1
	MonAgent   -l $level -i 300 $mq &
	sleep 1

	JrnlGen    -l $level -i 60
	JrnlTran   -l $level -i 60 -s 64.0.98.32 -p 31119
	MonCommSrv -l $level -p 22420 -a

	filekeep.sh start > /dev/null 2>&1 &
	# (cd $ATMPHFILE/moni  && ltfserv)
}

pid=`ps -u $LOGNAME -o user,pid,comm | awk '"mspknl"==$3{print $2}'`
if [ -z "$pid" ]; then
	echo "start msp"
	startmsp
fi

cd $HOME/bin
umask 002

echo "begin Init Share Memory now!"
shmmon30 -i

echo "start busi101"
busi30_ora -d bu101.debug -l $level -q 101 -n busi30_ora_101 &
busi30_ora -d bu101.debug -l $level -q 101 -n busi30_ora_101 &
busi30_ora -d bu101.debug -l $level -q 101 -n busi30_ora_101 &
busi30_ora -d bu101.debug -l $level -q 101 -n busi30_ora_101 &
busi30_ora -d bu101.debug -l $level -q 101 -n busi30_ora_101 &
sleep 1
echo "start busi102"
busi30_ora -d bu102.debug -l $level -q 102 -n busi30_ora_102 &
busi30_ora -d bu102.debug -l $level -q 102 -n busi30_ora_102 &
busi30_ora -d bu102.debug -l $level -q 102 -n busi30_ora_102 &
busi30_ora -d bu102.debug -l $level -q 102 -n busi30_ora_102 &
busi30_ora -d bu102.debug -l $level -q 102 -n busi30_ora_102 &
sleep 1
#echo "start busi103"
#busi30_ora -d bu103.debug -l $level -q 103 -n busi30_ora_103 &
#busi30_ora -d bu103.debug -l $level -q 103 -n busi30_ora_103 &
#busi30_ora -d bu103.debug -l $level -q 103 -n busi30_ora_103 &
#busi30_ora -d bu103.debug -l $level -q 103 -n busi30_ora_103 &
#busi30_ora -d bu103.debug -l $level -q 103 -n busi30_ora_103 &
#sleep 1
#echo "start busi104"
#busi30_ora -d bu104.debug -l $level -q 104 -n busi30_ora_104 &
#busi30_ora -d bu104.debug -l $level -q 104 -n busi30_ora_104 &
#busi30_ora -d bu104.debug -l $level -q 104 -n busi30_ora_104 &
#busi30_ora -d bu104.debug -l $level -q 104 -n busi30_ora_104 &
#busi30_ora -d bu104.debug -l $level -q 104 -n busi30_ora_104 &
#sleep 1

echo "start busi105"
busi30_ora -d bu105.debug -l $level -q 105 -n busi30_ora_105 &
busi30_ora -d bu105.debug -l $level -q 105 -n busi30_ora_105 &
busi30_ora -d bu105.debug -l $level -q 105 -n busi30_ora_105 &
busi30_ora -d bu105.debug -l $level -q 105 -n busi30_ora_105 &
busi30_ora -d bu105.debug -l $level -q 105 -n busi30_ora_105 &
sleep 1

echo "start busi106"
busi30_ora -d bu106.debug -l $level -q 106 -n busi30_ora_106 &
busi30_ora -d bu106.debug -l $level -q 106 -n busi30_ora_106 &
busi30_ora -d bu106.debug -l $level -q 106 -n busi30_ora_106 &
busi30_ora -d bu106.debug -l $level -q 106 -n busi30_ora_106 &
busi30_ora -d bu106.debug -l $level -q 106 -n busi30_ora_106 &
sleep 1

echo "start busi107"
busi30_ora -d bu107.debug -l $level -q 107 -n busi30_ora_107 &
busi30_ora -d bu107.debug -l $level -q 107 -n busi30_ora_107 &
busi30_ora -d bu107.debug -l $level -q 107 -n busi30_ora_107 &
busi30_ora -d bu107.debug -l $level -q 107 -n busi30_ora_107 &
busi30_ora -d bu107.debug -l $level -q 107 -n busi30_ora_107 &
sleep 1 

echo "start busi108"
busi30_ora -d bu108.debug -l $level -q 108 -n busi30_ora_108 &
busi30_ora -d bu108.debug -l $level -q 108 -n busi30_ora_108 &
busi30_ora -d bu108.debug -l $level -q 108 -n busi30_ora_108 &
busi30_ora -d bu108.debug -l $level -q 108 -n busi30_ora_108 &
busi30_ora -d bu108.debug -l $level -q 108 -n busi30_ora_108 &
sleep 1
#echo "start busi116"
#busi30_ora -d bu116.debug -l $level -q 116 -n busi30_ora_116 &
#busi30_ora -d bu116.debug -l $level -q 116 -n busi30_ora_116 &
#busi30_ora -d bu116.debug -l $level -q 116 -n busi30_ora_116 &
#busi30_ora -d bu116.debug -l $level -q 116 -n busi30_ora_116 &
#busi30_ora -d bu116.debug -l $level -q 116 -n busi30_ora_116 &
#sleep 1
#echo "start busi117"
#busi30_ora -d bu117.debug -l $level -q 117 -n busi30_ora_117 &
#busi30_ora -d bu117.debug -l $level -q 117 -n busi30_ora_117 &
#busi30_ora -d bu117.debug -l $level -q 117 -n busi30_ora_117 &
#busi30_ora -d bu117.debug -l $level -q 117 -n busi30_ora_117 &
#busi30_ora -d bu117.debug -l $level -q 117 -n busi30_ora_117 &
#sleep 1
#echo "start busi118"
#busi30_ora -d bu118.debug -l $level -q 118 -n busi30_ora_118 &
#busi30_ora -d bu118.debug -l $level -q 118 -n busi30_ora_118 &
#busi30_ora -d bu118.debug -l $level -q 118 -n busi30_ora_118 &
#busi30_ora -d bu118.debug -l $level -q 118 -n busi30_ora_118 &
#busi30_ora -d bu118.debug -l $level -q 118 -n busi30_ora_118 &
#sleep 1
#echo "start busi121"
#busi30_ora -d bu121.debug -l $level -q 121 -n busi30_ora_121 &
#busi30_ora -d bu121.debug -l $level -q 121 -n busi30_ora_121 &
#busi30_ora -d bu121.debug -l $level -q 121 -n busi30_ora_121 &
#busi30_ora -d bu121.debug -l $level -q 121 -n busi30_ora_121 &
#busi30_ora -d bu121.debug -l $level -q 121 -n busi30_ora_121 &
#sleep 1
#echo "start busi122"
#busi30_ora -d bu122.debug -l $level -q 122 -n busi30_ora_122 &
#busi30_ora -d bu122.debug -l $level -q 122 -n busi30_ora_122 &
#busi30_ora -d bu122.debug -l $level -q 122 -n busi30_ora_122 &
#busi30_ora -d bu122.debug -l $level -q 122 -n busi30_ora_122 &
#busi30_ora -d bu122.debug -l $level -q 122 -n busi30_ora_122 &
#sleep 1
#echo "start busi125"
#busi30_ora -d bu125.debug -l $level -q 125 -n busi30_ora_125 &
#busi30_ora -d bu125.debug -l $level -q 125 -n busi30_ora_125 &
#busi30_ora -d bu125.debug -l $level -q 125 -n busi30_ora_125 &
#busi30_ora -d bu125.debug -l $level -q 125 -n busi30_ora_125 &
#busi30_ora -d bu125.debug -l $level -q 125 -n busi30_ora_125 &
#sleep 1
#echo "start busi126"
#busi30_ora -d bu126.debug -l $level -q 126 -n busi30_ora_126 &
#busi30_ora -d bu126.debug -l $level -q 126 -n busi30_ora_126 &
#busi30_ora -d bu126.debug -l $level -q 126 -n busi30_ora_126 &
#busi30_ora -d bu126.debug -l $level -q 126 -n busi30_ora_126 &
#busi30_ora -d bu126.debug -l $level -q 126 -n busi30_ora_126 &
#sleep 1
#
#echo "start secu846"
#secu30_ora -d  secu.debug -m 846 -l $level -n secu30_ora_846 &
#secu30_ora -d  secu.debug -m 846 -l $level -n secu30_ora_846 &
#secu30_ora -d  secu.debug -m 846 -l $level -n secu30_ora_846 &
#secu30_ora -d  secu.debug -m 846 -l $level -n secu30_ora_846 &
#secu30_ora -d  secu.debug -m 846 -l $level -n secu30_ora_846 &
#sleep 1


echo "start secu847"
secu30_ora -d  secu.debug -m 847 -l $level -n secu30_ora_851 &
secu30_ora -d  secu.debug -m 847 -l $level -n secu30_ora_851 &
secu30_ora -d  secu.debug -m 847 -l $level -n secu30_ora_851 &
secu30_ora -d  secu.debug -m 847 -l $level -n secu30_ora_851 &
secu30_ora -d  secu.debug -m 847 -l $level -n secu30_ora_851 &
sleep 1
#
#echo "start secu861"
#secu30_ora -d  secu.debug -m 861 -l $level -n secu30_ora_861 &
#secu30_ora -d  secu.debug -m 861 -l $level -n secu30_ora_861 &
#secu30_ora -d  secu.debug -m 861 -l $level -n secu30_ora_861 &
#secu30_ora -d  secu.debug -m 861 -l $level -n secu30_ora_861 &
#secu30_ora -d  secu.debug -m 861 -l $level -n secu30_ora_861 &
#sleep 1

#echo "start switch800"
#switch_ora -d    sw.debug -m 800 -l $level -n switch_ora_800 &
#switch_ora -d    sw.debug -m 800 -l $level -n switch_ora_800 &
#switch_ora -d    sw.debug -m 800 -l $level -n switch_ora_800 &
#switch_ora -d    sw.debug -m 800 -l $level -n switch_ora_800 &
#switch_ora -d    sw.debug -m 800 -l $level -n switch_ora_800 &
#switch_ora -d    sw.debug -m 800 -l $level -n switch_ora_800 &
#switch_ora -d    sw.debug -m 800 -l $level -n switch_ora_800 &
#switch_ora -d    sw.debug -m 800 -l $level -n switch_ora_800 &
#switch_ora -d    sw.debug -m 800 -l $level -n switch_ora_800 &
#switch_ora -d    sw.debug -m 800 -l $level -n switch_ora_800 &
#sleep 1

echo "start switch805"
switch_ora -d    sw.debug -m 805 -l $level -n switch_ora_805 &
switch_ora -d    sw.debug -m 805 -l $level -n switch_ora_805 &
switch_ora -d    sw.debug -m 805 -l $level -n switch_ora_805 &
switch_ora -d    sw.debug -m 805 -l $level -n switch_ora_805 &
switch_ora -d    sw.debug -m 805 -l $level -n switch_ora_805 &
switch_ora -d    sw.debug -m 805 -l $level -n switch_ora_805 &
switch_ora -d    sw.debug -m 805 -l $level -n switch_ora_805 &
switch_ora -d    sw.debug -m 805 -l $level -n switch_ora_805 &
switch_ora -d    sw.debug -m 805 -l $level -n switch_ora_805 &
sleep 1 

echo "start switch806"
switch_ora -d    sw.debug -m 806 -l $level -n switch_ora_806 &
switch_ora -d    sw.debug -m 806 -l $level -n switch_ora_806 &
switch_ora -d    sw.debug -m 806 -l $level -n switch_ora_806 &
switch_ora -d    sw.debug -m 806 -l $level -n switch_ora_806 &
switch_ora -d    sw.debug -m 806 -l $level -n switch_ora_806 &
switch_ora -d    sw.debug -m 806 -l $level -n switch_ora_806 &
switch_ora -d    sw.debug -m 806 -l $level -n switch_ora_806 &
switch_ora -d    sw.debug -m 806 -l $level -n switch_ora_806 &
switch_ora -d    sw.debug -m 806 -l $level -n switch_ora_806 &
sleep 1


#echo "start channel201"
#channel30_ora -c 201 -m 201 -l $level -i 0 -n channel30_ora_201 &
#channel30_ora -c 201 -m 201 -l $level -i 0 -n channel30_ora_201 &
#channel30_ora -c 201 -m 201 -l $level -i 0 -n channel30_ora_201 &
#channel30_ora -c 201 -m 201 -l $level -i 0 -n channel30_ora_201 &
#channel30_ora -c 201 -m 201 -l $level -i 0 -n channel30_ora_201 &
#sleep 1


#echo "start channel202"
#channel30_ora -c 202 -m 202 -l $level -i 0 -n channel30_ora_202 &
#channel30_ora -c 202 -m 202 -l $level -i 0 -n channel30_ora_202 &
#channel30_ora -c 202 -m 202 -l $level -i 0 -n channel30_ora_202 &
#channel30_ora -c 202 -m 202 -l $level -i 0 -n channel30_ora_202 &
#channel30_ora -c 202 -m 202 -l $level -i 0 -n channel30_ora_202 &
#sleep 1



echo "start channel205"
channel30_ora -c 205 -m 205 -l $level -i 0 -n channel30_ora_205 &
channel30_ora -c 205 -m 205 -l $level -i 0 -n channel30_ora_205 &
channel30_ora -c 205 -m 205 -l $level -i 0 -n channel30_ora_205 &
channel30_ora -c 205 -m 205 -l $level -i 0 -n channel30_ora_205 &
channel30_ora -c 205 -m 205 -l $level -i 0 -n channel30_ora_205 &
sleep 1

#
#echo "start channel230"
#channel30_ora -c 230 -m 230 -l $level -i 0 -n channel30_ora_230 &
#sleep 1

#echo "start channel405"
#channel30_ora -c 405 -m 405 -l $level -i 0 -n channel30_ora_405 &
#channel30_ora -c 405 -m 405 -l $level -i 0 -n channel30_ora_405 &
#channel30_ora -c 405 -m 405 -l $level -i 0 -n channel30_ora_405 &
#channel30_ora -c 405 -m 405 -l $level -i 0 -n channel30_ora_405 &
#channel30_ora -c 405 -m 405 -l $level -i 0 -n channel30_ora_405 &
#sleep 1



echo "start channel406"
channel30_ora -c 406 -m 406 -l $level -i 0 -n channel30_ora_406 &
channel30_ora -c 406 -m 406 -l $level -i 0 -n channel30_ora_406 &
channel30_ora -c 406 -m 406 -l $level -i 0 -n channel30_ora_406 &
channel30_ora -c 406 -m 406 -l $level -i 0 -n channel30_ora_406 &
channel30_ora -c 406 -m 406 -l $level -i 0 -n channel30_ora_406 &
sleep 1 

echo "start channel407"
channel30_ora -c 407 -m 407 -l $level -i 0 -n channel30_ora_407 &
channel30_ora -c 407 -m 407 -l $level -i 0 -n channel30_ora_407 &
channel30_ora -c 407 -m 407 -l $level -i 0 -n channel30_ora_407 &
channel30_ora -c 407 -m 407 -l $level -i 0 -n channel30_ora_407 &
channel30_ora -c 407 -m 407 -l $level -i 0 -n channel30_ora_407 &
#
#echo "start channel421"
#channel30_ora -c 421 -m 421 -l $level -i 0 -n channel30_ora_421 &
#channel30_ora -c 421 -m 421 -l $level -i 0 -n channel30_ora_421 &
#channel30_ora -c 421 -m 421 -l $level -i 0 -n channel30_ora_421 &
#channel30_ora -c 421 -m 421 -l $level -i 0 -n channel30_ora_421 &
#channel30_ora -c 421 -m 421 -l $level -i 0 -n channel30_ora_421 &
#sleep 1
#
#
#echo "start channel422"
#channel30_ora -c 422 -m 422 -l $level -i 0 -n channel30_ora_422 &
#channel30_ora -c 422 -m 422 -l $level -i 0 -n channel30_ora_422 &
#channel30_ora -c 422 -m 422 -l $level -i 0 -n channel30_ora_422 &
#channel30_ora -c 422 -m 422 -l $level -i 0 -n channel30_ora_422 &
#channel30_ora -c 422 -m 422 -l $level -i 0 -n channel30_ora_422 &
#sleep 1
#
#echo "start channel430"
#channel30_ora -c 430 -m 430 -l $level -i 0 -n channel30_ora_430 &
#channel30_ora -c 430 -m 430 -l $level -i 0 -n channel30_ora_430 &
#channel30_ora -c 430 -m 430 -l $level -i 0 -n channel30_ora_430 &
#channel30_ora -c 430 -m 430 -l $level -i 0 -n channel30_ora_430 &
#channel30_ora -c 430 -m 430 -l $level -i 0 -n channel30_ora_430 &
#sleep 1
#
#echo "start channel440"
#channel30_ora -c 440 -m 440 -l $level -i 1 -n channel30_ora_440 &
#channel30_ora -c 440 -m 440 -l $level -i 1 -n channel30_ora_440 &
#channel30_ora -c 440 -m 440 -l $level -i 1 -n channel30_ora_440 &
#channel30_ora -c 440 -m 440 -l $level -i 1 -n channel30_ora_440 &
#channel30_ora -c 440 -m 440 -l $level -i 1 -n channel30_ora_440 &
#sleep 1

echo "start WorkLog"
worklog30 -d WorkLog.debug  -l $level -p 5 -n worklog30 &

echo "start APMonitor"
APMonitor -d APMonitor.debug -l $level -n APMonitor &
#APTimer   -d APTimer.debug   -l $level

#echo "start JrnlGet"
#JrnlGet -m 599 -f 5 &

sleep 1 

#AP2Out_Cli30 -l $level -n AP2Out_Cli30 &
#AP2Bal_Cli30 -l $level -n AP2Bal_Cli30 &

#echo "TCRP1.0�汾��"
#cat $VERFILE
 
exit 0
