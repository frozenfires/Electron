#!/bin/sh
#
# Copyright (C), 1988-2012, Nantian Co., Ltd.
# 
# $Id: killname.sh,v 1.2.2.2 2011/07/09 09:40:58 mymtom Exp $
# 
# $Log: killname.sh,v $
# Revision 1.2.2.2  2011/07/09 09:40:58  mymtom
# uncomment
#
# Revision 1.2.2.1  2011/07/07 06:54:36  mymtom
# support -a option for full args match
#
# Revision 1.2  2011/06/17 09:26:49  mymtom
# REL_1_2
#
# Revision 1.1  2011/06/17 09:26:36  mymtom
# Initial revision
#
# Revision 1.0  2010/05/18 01:50:56  atmph
# Initial revision
#
#

me=""
procs=""
aflag=0
uflag=u
oflag=0
signo=""

usage()
{
	echo "usage: killname [-signal_name | -signal_number] process_name ..."
	exit 1
}

look_ps_opts()
{
	me=`whoami`
	if [ $? -ne 0 ]; then
		me=`logname`
	fi
	if [ $? -ne 0 ]; then
		me=${LOGNAME}
	fi

	ps -${uflag} ${me} > /dev/null 2>&1
	if [ $? -eq 0 ]; then
		uflag=u
	else
		uflag=U
	fi

	ps -o pid,comm  > /dev/null 2>&1
	if [ $? -eq 0 ]; then
		oflag=0
	else
		oflag=1
	fi
}

kill_by_name()
{
	if [ ${oflag} -eq 0 ]; then
		procs=`ps -o user,pid,ppid,tty,comm -${uflag} ${me} \
			| awk '$5=="'$1'"{print $2}'`
	else
		procs=`ps -l -${uflag} ${me} | awk '$NF=="'$1'"{print $(NF-10)}'`
	fi

	if [ -n "${procs}" ]; then
		if [ ${oflag} -eq 0 ]; then
			ps -p `echo ${procs} | sed -e 's/ /,/g'` -o user,pid,ppid,tty,args
		else
			ps -p `echo ${procs} | sed -e 's/ /,/g'` -l
		fi
		kill ${signo} ${procs}
		mspkill ${procs}
	fi
}


kill_by_args()
{
	if [ ${oflag} -eq 0 ]; then
		procs=`ps -o user,pid,ppid,tty,args -${uflag} ${me} | awk ' {
			args = $5;
			for (i=6; i <= NF; i++) {
				args = args " " $i;
			}
			if (args == "'"$*"'") {
				print $2;
			}
		}'`
	else
		procs=`ps -f -${uflag} ${me} | awk ' {
			args = $8;
			for (i=9; i <= NF; i++) {
				args = args " " $i;
			}
			if (args == "'"$*"'") {
				print $2;
			}
		}'`
	fi

	if [ -n "${procs}" ]; then
		if [ ${oflag} -eq 0 ]; then
			ps -p `echo ${procs} | sed -e 's/ /,/g'` -o user,pid,ppid,tty,args
		else
			ps -p `echo ${procs} | sed -e 's/ /,/g'` -l
		fi
		kill ${signo} ${procs}
		mspkill ${procs}
	fi
}


if [ $# -lt 1 ]; then
	usage
fi

while true; do
case "$1" in
-0|-1|-2|-3|-6|-9|-14|-15|-30|31)
	signo="$1"
	shift
	;;
-HUP|-INT|-QUIT|-ABRT|-KILL|-ALRM|-TERM|-USR1|-USR2)
	signo="$1"
	shift
	;;
-a)
	aflag=1
	shift
	;;
-s)
	signo="$1 $2"
	shift
	shift
	;;
-*)
	signo="$1"
	shift
	;;
*)
	break
	;;
esac
done

if [ $# -lt 1 ]; then
	usage
fi

look_ps_opts

if [ $aflag -eq 0 ]; then
for name in "$@"; do
	kill_by_name $name
done
else
for args in "$@"; do
	kill_by_args $args
done
fi

