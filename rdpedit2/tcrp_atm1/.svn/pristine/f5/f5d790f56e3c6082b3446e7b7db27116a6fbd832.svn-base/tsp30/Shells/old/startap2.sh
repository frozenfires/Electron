#!/bin/sh
#
# Copyright (C) 1988-2010, Nantian Co., Ltd.
#
# $Id: startap2.sh,v 1.2 2010/11/04 15:12:50 mymtom Exp $
#
# $Log: startap2.sh,v $
# Revision 1.2  2010/11/04 15:12:50  mymtom
# REL_1_2
#
# Revision 1.1.1.1  2010/08/14 20:19:29  cvsadmin
# Initial import
#
# Revision 1.2  2010/08/02 10:37:37  mymtom
# Add to CVS
#
# Revision 1.1  2010/05/06 06:16:13  mymtom
#
# Revision 1.0  2010/04/21 10:45:54  mymtom
# Initial revision
#
#

level=1

sys_mon_start()
{
	mq=`awk -F"[ \t]+" '
		BEGIN { head = 0;tail = 0; }
		head == 1 && $1 == "[END]" { tail=1; }
		head == 1 && tail == 0 && NF == 7 { print $1; }
		$1 == "[MAILBOXCFG]" { head=1; }' $MSP_DIR/etc/mspsrv.cfg`
	MonProxy   -l $level &
	sleep 1
	MonAgent   -l $level -i 300 $mq &
	sleep 1

	JrnlGen    -l $level -i 60
	JrnlTran   -l $level -i 60 -s 64.0.98.32 -p 31119
	MonCommSrv -l $level -p 22421 -a

	filekeep.sh start > /dev/null 2>&1 &
	# (cd $ATMPHFILE/moni  && ltfserv)
}

cd $HOME/bin
umask 002
pid=`ps -u $LOGNAME -o user,pid,comm | awk '"mspknl"==$3{print $2}'`
if [ -z "$pid" ]; then
	startmsp
fi

echo "begin Init Share Memory now!"
shmmon30 -i
datasync -i -v m20_cardtable      >  $TSP_DEBUG_PATH/datasync.debug 
datasync -i -v m20_conf_curr      >> $TSP_DEBUG_PATH/datasync.debug
datasync -i -v m20_conf_notes     >> $TSP_DEBUG_PATH/datasync.debug
datasync -i -v m20_conf_dcccode   >> $TSP_DEBUG_PATH/datasync.debug
datasync -i -v m20_msgexch        >> $TSP_DEBUG_PATH/datasync.debug
datasync -i -v m20_conf_lckinfo   >> $TSP_DEBUG_PATH/datasync.debug
datasync -i -v m09_sys_mon_config >> $TSP_DEBUG_PATH/datasync.debug
datasync -i -v m06_busiway        >> $TSP_DEBUG_PATH/datasync.debug

sleep 1


echo "start busi100"
busi30_ifx -d bu100.debug -l $level -q 100 -n busi30_ifx_100 &
busi30_ifx -d bu100.debug -l $level -q 100 -n busi30_ifx_100 &
busi30_ifx -d bu100.debug -l $level -q 100 -n busi30_ifx_100 &
busi30_ifx -d bu100.debug -l $level -q 100 -n busi30_ifx_100 &
busi30_ifx -d bu100.debug -l $level -q 100 -n busi30_ifx_100 &

sleep 1


echo "start busi103"
busi30_ifx -d bu103.debug -l $level -q 103 -n busi30_ifx_103 &
busi30_ifx -d bu103.debug -l $level -q 103 -n busi30_ifx_103 &

sleep 1


echo "start busi120"
busi30_ifx -d bu120.debug -l $level -q 120 -n busi30_ifx_120 &
busi30_ifx -d bu120.debug -l $level -q 120 -n busi30_ifx_120 &
busi30_ifx -d bu120.debug -l $level -q 120 -n busi30_ifx_120 &
busi30_ifx -d bu120.debug -l $level -q 120 -n busi30_ifx_120 &
busi30_ifx -d bu120.debug -l $level -q 120 -n busi30_ifx_120 &

sleep 1


echo "start busi123"
busi30_ifx -d bu123.debug -l $level -q 123 -n busi30_ifx_123 &

echo "start busi130"
busi30_ifx -d bu130.debug -l $level -q 130 -n busi30_ifx_130 &
busi30_ifx -d bu130.debug -l $level -q 130 -n busi30_ifx_130 &
busi30_ifx -d bu130.debug -l $level -q 130 -n busi30_ifx_130 &
busi30_ifx -d bu130.debug -l $level -q 130 -n busi30_ifx_130 &
busi30_ifx -d bu130.debug -l $level -q 130 -n busi30_ifx_130 &

sleep 1


echo "start busi136"
busi30_ifx -d bu136.debug -l $level -q 136 -n busi30_ifx_136 &

echo "start busi140"
busi30_ifx -d bu140.debug -l $level -q 140 -n busi30_ifx_140 &
busi30_ifx -d bu140.debug -l $level -q 140 -n busi30_ifx_140 &
busi30_ifx -d bu140.debug -l $level -q 140 -n busi30_ifx_140 &
busi30_ifx -d bu140.debug -l $level -q 140 -n busi30_ifx_140 &
busi30_ifx -d bu140.debug -l $level -q 140 -n busi30_ifx_140 &

sleep 1


echo "start busi146"
busi30_ifx -d bu146.debug -l $level -q 146 -n busi30_ifx_146 &
busi30_ifx -d bu146.debug -l $level -q 146 -n busi30_ifx_146 &

echo "start busi150"
busi30_ifx -d bu150.debug -l $level -q 150 -n busi30_ifx_150 &
busi30_ifx -d bu150.debug -l $level -q 150 -n busi30_ifx_150 &


echo "start busi152"
busi30_ifx -d bu152.debug -l $level -q 152 -n busi30_ifx_152 &
busi30_ifx -d bu152.debug -l $level -q 152 -n busi30_ifx_152 &
sleep 1


echo "start secu"
secu30_ifx -d  secu.debug -l $level -n secu30_ifx &
secu30_ifx -d  secu.debug -l $level -n secu30_ifx &
secu30_ifx -d  secu.debug -l $level -n secu30_ifx &
secu30_ifx -d  secu.debug -l $level -n secu30_ifx &
secu30_ifx -d  secu.debug -l $level -n secu30_ifx &

sleep 1


echo "start switch"
switch_ifx -d    sw.debug -l $level -n switch_ifx &
switch_ifx -d    sw.debug -l $level -n switch_ifx &

echo "start channel200"
channel30_ifx -c 200 -m 200 -l $level -i 0 -n channel30_ifx_200 &

echo "start channel203"
channel30_ifx -c 203 -m 203 -l $level -i 0 -n channel30_ifx_203 &

sleep 1


echo "start channel400"
channel30_ifx -c 400 -m 400 -l $level -i 0 -n channel30_ifx_400400 &
channel30_ifx -c 400 -m 500 -l $level -i 0 -n channel30_ifx_400500 &
channel30_ifx -c 400 -m 502 -l $level -i 0 -n channel30_ifx_400502 &
channel30_ifx -c 400 -m 503 -l $level -i 0 -n channel30_ifx_400503 &
channel30_ifx -c 400 -m 504 -l $level -i 0 -n channel30_ifx_400504 &

channel30_ifx -c 400 -m 505 -l $level -i 0 -n channel30_ifx_400505 &
channel30_ifx -c 400 -m 505 -l $level -i 0 -n channel30_ifx_400505 &

channel30_ifx -c 400 -m 506 -l $level -i 0 -n channel30_ifx_400506 &

sleep 1


echo "start channel406"
channel30_ifx -c 406 -m 406 -l $level -i 1 -n channel30_ifx_406406 &

echo "start channel410"
channel30_ifx -c 410 -m 410 -l $level -i 0 -n channel30_ifx_410410 &

sleep 1


echo "start WorkLog"
worklog30 -d WorkLog.debug  -l $level -p 25 -n worklog30 &

echo "start APMonitor"
APMonitor -d APMonitor.debug -l $level -n APMonitor &
APTimer   -d APTimer.debug   -l $level

echo "start SysMon"
sys_mon_start

#echo "start ChcfileSendSrv"
#ChcfileSendSrv -d  ChcfileSendSrv.debug -l 2 &
sleep 1



AP2Out_Cli30 -l $level -n AP2Out_Cli30 &
AP2Bal_Cli30 -l $level -n AP2Bal_Cli30 &

sleep 1

echo "ATMP2.0�汾��"
cat $VERFILE
 
exit 0
