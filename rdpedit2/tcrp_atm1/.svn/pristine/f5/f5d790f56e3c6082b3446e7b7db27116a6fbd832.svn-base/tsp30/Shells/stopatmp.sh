#!/bin/sh

stopap.sh

balcomm.sh stop

outcomm.sh stop


#echo "ap logout"
#APLogin -o
#sleep 10

exit 0
         
