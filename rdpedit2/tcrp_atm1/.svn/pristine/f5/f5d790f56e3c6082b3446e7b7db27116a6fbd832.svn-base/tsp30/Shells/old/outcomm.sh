#!/bin/sh
#
# Copyright (C) 1988-2010, Nantian Co., Ltd.
#
# $Id: outcomm.sh,v 1.2 2010/11/04 15:12:46 mymtom Exp $
#
# $Log: outcomm.sh,v $
# Revision 1.2  2010/11/04 15:12:46  mymtom
# REL_1_2
#
# Revision 1.1.1.1  2010/08/14 20:19:29  cvsadmin
# Initial import
#
# Revision 1.2  2010/08/02 10:37:37  mymtom
# Add to CVS
#
# Revision 1.0  2010/05/06 07:22:29  atmphuat
# Initial revision
#
#

outcomm_start()
{
	pid=`ps -u $LOGNAME -o user,pid,ppid,vsz,comm | awk '"mspknl"==$5{print $2}'`
	if [ -z "$pid" ]; then
		startmsp
	fi
	cd $HOME/bin
	echo "starting outcomm ..."
	Out2AP_Srv30 -l 2 &
	sleep 1

	echo $DCCNAME
	#sec_init $LOCAL_BANK_ID
	#sleep 1

	CommClientSA_SL30 -l 3 -m 700 -n CommClientSA_SL30_700 -d CommClientSA_SL30_700.debug &
	CommClientSA_SL30 -l 3 -m 701 -n CommClientSA_SL30_701 -d CommClientSA_SL30_701.debug &
	CommClientSA_SL30 -l 3 -m 702 -n CommClientSA_SL30_702 -d CommClientSA_SL30_702.debug &
	CommClientSA_SL30 -l 3 -m 703 -n CommClientSA_SL30_703 -d CommClientSA_SL30_703.debug &

	sleep 1
}

outcomm_stop()
{
	echo "stopping outcomm ..."

	killname Out2AP_Srv30
	sleep 1

	killname CommClientSA_SL30
	sleep 1

	pid=`ps -u $LOGNAME -o user,pid,comm | awk '$3 ~ /^switch|^BalComm|^CommClient/{print}'`
	if [ -z "$pid" ]; then
		sleep 1
		mspknl -d 2
	fi

	Out2AP_Srv30 -u
	sleep 1

	#sec_stop $LOCAL_BANK_ID
	sleep 1

	#filekeep.sh stop
}

case "$1" in
start)
	outcomm_start
	;;
stop )
	outcomm_stop
	;;
""|restart)
	outcomm_stop
	sleep 2
	outcomm_start
	;;
esac

